# Promise episode delivery

This is a new episode built from the uploaded I Kept a Promise to Myself Today.mp4, not a reuse of a previous episode's cut map. The final is designed for 1280×720 at 30 fps and three minutes.

## Deliverables

- I_Kept_a_Promise_Final.mp4: final render; see QC_Report.md for actual verification.
- Promise_Preview.mp4: the single 15-second, 640×360 QC sampler, not a trailer.
- Promise_Cover.jpg: 1280×720 YouTube cover, actual source frame 14,745.
- YouTube_Packaging.md: title, description, chapter times, tags, and actual music credits.
- Episode_Brief.md, Source_Inspection.md, Cut_Plan.md, Episode_Edit.json: this episode's decisions and source map.
- Editable_Project.zip: existing editor plus new episode files, original source, prepared music, npm lockfile, license record, and grade preset. node_modules and old renders are excluded.
- review/: supporting probes, logs, image checks, and audio/QC measurements. Failed transcription is documented as unavailable, not treated as footage evidence.

## Continue editing

Unzip Editable_Project.zip to a new directory. Read daily-remotion-gym-editor/README.md and this file first. Existing source files and assets are preserved. The episode's registration is separate from the older Root.tsx so old episodes do not need their missing source videos to render this episode.

From daily-remotion-gym-editor:

```sh
npm ci
npm run lint
npx remotion studio src/promise-index.ts --no-open
```

Edit src/promise-edit.json and src/PromiseEpisode.tsx. The new wrapper reuses the existing UpperBodyScienceComposition pattern and the existing BrandIntro and BrandOutro directly, with an inset adapted from the existing short layout. The V2 color preset's contrast/saturation baseline is retained with small episode-specific exposure lifts. No old source timecodes or source-specific grade curves were reused.

Media is self-contained under public/. Source path: public/media/promise-episode/source.mp4. Its SHA-256 must remain ddfed6a2d8879c1ae51925049552ba44a3ffbe3076e89451ba336ab5fe2937d7. Do not overwrite it. Music originals remain in public/media/; episode working WAVs are separate under public/media/promise-episode/.

For a later revision, choose fresh output paths. Do not rerun over the delivered files. The original task's one preview and one final were already rendered. Example commands for a separately requested revision:

```sh
npx remotion render src/promise-index.ts PromiseEpisodePreview ../NEW_revision_preview.mp4 --codec=h264 --audio-codec=aac --concurrency=1 --scale=0.5 --crf=20
npx remotion render src/promise-index.ts PromiseEpisodeFinal ../NEW_revision_final.mp4 --codec=h264 --audio-codec=aac --audio-bitrate=192k --sample-rate=48000 --concurrency=2 --crf=18 --pixel-format=yuv420p
```

Remotion may download its browser on a new machine. This cloud render used the existing /usr/bin/chromium via --browser-executable=/usr/bin/chromium and --gl=angle; that Linux-specific path is not needed on a Mac. File overwrite protection remains enabled in remotion.config.ts.

Cover entry point: src/promise-cover-index.tsx, composition PromiseCover. It uses a real source video frame; it does not generate or alter the creator's body or face.

## Limits

The source is already compressed 720p; this edit preserves native output resolution and cannot recover missing detail. Source framing is retained within its active image. No ice-bath scene, commentary, rep totals, weights, training outcomes, or science claim are added. The creator confirmed replacement of the source audio. The retained Mixkit license record is supplied evidence, not a fresh legal review. No video has been published.
