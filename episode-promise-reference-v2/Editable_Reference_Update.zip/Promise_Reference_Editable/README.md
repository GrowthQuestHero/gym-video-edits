# Daily Remotion Gym Editor — authoritative workflow

Use this project for a source-led long edit, a Short from a completed edit, color changes to an existing edit, or YouTube packaging. The existing compositions and episode files in `src/` remain the working examples; their timecodes belong only to their original footage. This README is the single project instruction entry point. `daily-gym-editor/SKILL.md` describes the separate Swift workflow.

## Episode input

Provide an exact source file or completed project, a short creative brief, and any optional target length or aspect ratio. Mark weights, distances, rep counts, exercise names, personal outcomes, and other unverified claims as **unverified** until footage or reliable records support them. Keep each episode's shot map, cut map, grade overrides, music/SFX choices, captions, and packaging decisions in its own files. Do not copy another episode's source timecodes.

## Shared rules

- Preserve original media, existing projects, presets, licensed assets, and finished exports. Choose a new output path before rendering; Remotion is configured to reject overwrites.
- Inspect the actual source or completed edit once at low cost. Confirm exercises and sequence from footage, preserve meaningful speech, and do not use copyright-uncertain camera music. Use the saved Mixkit license record at `../daily-gym-editor/assets/V2_Audio_Credits_Original.md` for approved library assets.
- Keep captions truthful, legible, and clear of faces and movements. Correct exposure and white balance before a restrained look; retain natural skin tones and visible shadow detail.
- Before a full render, verify the source is unambiguous, probe its duration/resolution/fps/audio, check each cut against source bounds, confirm referenced media and license records exist, and check that the destination is new. Preview the opening, a representative middle shot, and the ending. Render once after review.
- After rendering, verify stream properties, expected frame count/duration, full decode, opening/ending picture, captions where used, and audible, unclipped audio. Record unresolved limits instead of calling an untested result complete.

## Modes

| Mode | Use | Existing implementation and boundary |
|---|---|---|
| **long** | Edit a verified recording into a horizontal story. | `UpperBodyScienceComposition.tsx` + `upper-body-science-edit.json`, `RunComposition.tsx` + `run-config.ts`, `LegDayRunComposition.tsx` + `leg-run-edit.json`, and `WarmupComposition.tsx` are working examples. Inspect new footage and create its own plan; clip choice and claims need editorial review. |
| **short** | Make a vertical Short from a completed project. | `UpperBodyShortV2.tsx` + `upper-body-short-v2.json`, `LegDayRunShort.tsx`, `RunningShort.tsx`, and `WarmupShort.tsx` are working examples. Reframe per clip; check that the configured cut durations total the intended frame count. Do not assume a finished long edit's timecodes fit another video. |
| **grade-only** | Correct color while preserving an existing edit. | The Upper Body V2 example uses `upper-body-science-grade-v2.json`, `grade_upper_body_v2.py`, and `UpperBodyScienceGradeV2.tsx`. Keep the original cut map, audio, captions, fps, and duration. Compare their values before/after and preview affected shots. The grading script is episode-specific and writes its shot files: use a separate copy/output for a new grade, never rerun it over the saved V2 assets. |
| **package** | Prepare truthful publishing material from verified footage. | Existing examples live in `../output/*/YouTube_Packaging.md`. `scripts/make_cover.py` and `scripts/make_run_thumbnails.py` make real-frame images for their configured projects. Write titles, description, hashtags, tags, and audio credit from the episode's verified map. For a new episode, adapt image inputs/output paths; there is no generic automatic title or exercise detector. |

## Preview and status

From this directory, run `npm run lint`, then render a **new short preview path** with `./node_modules/.bin/remotion render src/index.ts <PreviewCompositionId> <new-path>.mp4 --codec=h264 --concurrency=1`. `RunningStoryPreview` is a horizontal example; `UpperBodyShortV2-Preview` is vertical. Existing preview compositions may be longer than a few seconds; use `--frames=0-149` for a five-second smoke test when appropriate. Check the actual output rather than trusting the command's exit status alone. Use the matching final composition only after the plan and preview pass; never reuse a published output path.

Report each mode as **verified**, **partially verified**, or **unverified** according to observed tests. A preview proves only preview rendering and framing, not a new episode's complete editorial quality or a final export. No installation or full render is needed for a packaging-only run.

## Daily requests

These are short prompts to give Codex with an exact file/project and brief; they route through the modes above, not through a new automatic editor:

1. `Edit long: source=<exact file>; episode=<brief>. Use daily-remotion-gym-editor.`
2. `Make Short: project=<completed project>; 58s, 9:16. Use daily-remotion-gym-editor.`
3. `Grade only: project=<completed project>; look=natural athletic contrast. Preserve cuts/audio/captions.`
4. `Package: project=<completed project>; truthful metadata and 3 real-frame thumbnail options.`
