// Times refer to the single 180.17-second, 24 fps supplied MP4.
// The hook previews a later lunge; the remainder follows source chronology.
export type WarmupSection='hook'|'arms'|'triceps'|'wrists'|'legs'|'lunge'|'floor'|'kneel'|'hamstring'|'back'|'cardio'|'ending';
export type WarmupCut={sourceStart:number;seconds:number;section:WarmupSection;name:string};
export const warmupFps=24;
export const warmupCuts:WarmupCut[]=[
  {sourceStart:65,seconds:4,section:'hook',name:'Side-lunge hook'},
  {sourceStart:12,seconds:6,section:'arms',name:'Warm-up begins'},
  {sourceStart:18,seconds:9,section:'arms',name:'Arm circles'},
  {sourceStart:28,seconds:8,section:'triceps',name:'Overhead arm stretch'},
  {sourceStart:39,seconds:11,section:'wrists',name:'Wrist movement'},
  {sourceStart:51,seconds:9,section:'legs',name:'Standing leg stretch'},
  {sourceStart:61,seconds:16,section:'lunge',name:'Side lunges'},
  {sourceStart:80,seconds:14,section:'floor',name:'Floor mobility'},
  {sourceStart:97,seconds:10,section:'kneel',name:'Kneeling lunge stretch'},
  {sourceStart:108,seconds:14,section:'hamstring',name:'Hamstring stretch'},
  {sourceStart:123,seconds:9,section:'hamstring',name:'Stretch continues'},
  {sourceStart:135,seconds:10,section:'back',name:'Back extension'},
  {sourceStart:149,seconds:18,section:'cardio',name:'Treadmill warm-up'},
  {sourceStart:172,seconds:4,section:'ending',name:'Session closes'},
];
export const warmupDuration=warmupCuts.reduce((sum,cut)=>sum+cut.seconds,0);
export const warmupFrames=warmupDuration*warmupFps;
export const warmupCaptions=[
  {from:0,seconds:4,text:'WORKOUT SURU HUNU AGADI...'},
  {from:5,seconds:4,text:'PREPARATION MATTERS.'},
  {from:13,seconds:4,text:'1% BETTER WITH BIBEK  •  WARM-UP'},
  {from:34,seconds:3,text:'ARMS & WRISTS.'},
  {from:55,seconds:3,text:'MOVEMENT FIRST.'},
  {from:82,seconds:3,text:'LOWER BODY MOBILITY.'},
  {from:121,seconds:3,text:'CARDIO TO FINISH.'},
  {from:138,seconds:4,text:'1% BETTER EVERY DAY.'},
];
