import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import plan from './warmup-strength-edit.json';

type Cut = (typeof plan.cuts)[number];
const fps = plan.fps;
const total = plan.cuts.reduce((sum, cut) => sum + cut.seconds * fps, 0);

const Caption: React.FC<{text: string; duration: number}> = ({text, duration}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [0, 8, Math.max(9, duration - 12), duration - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{alignItems:'flex-start', justifyContent:'flex-start', padding:'36px 48px', pointerEvents:'none'}}>
    <div style={{font:'800 34px Arial, Helvetica, sans-serif', color:'#f8f8f2', letterSpacing:1.1, background:'rgba(7,14,20,.66)', borderLeft:'4px solid #c7d8cf', padding:'10px 17px', textShadow:'0 2px 8px #000', opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot: React.FC<{cut: Cut}> = ({cut}) => {
  const frames = cut.seconds * fps;
  return <AbsoluteFill style={{background:'#10191d'}}>
    <OffthreadVideo src={staticFile(plan.source)} muted trimBefore={cut.sourceStart * fps} durationInFrames={frames} style={{width:'100%', height:'100%', objectFit:'cover', filter:plan.grade}} />
    {cut.caption ? <Sequence from={8} durationInFrames={Math.min(frames - 8, 100)}><Caption text={cut.caption} duration={Math.min(frames - 8, 100)} /></Sequence> : null}
  </AbsoluteFill>;
};

const Story: React.FC<{cuts: Cut[]}> = ({cuts}) => {
  const duration = cuts.reduce((sum, cut) => sum + cut.seconds * fps, 0);
  let at = 0;
  return <AbsoluteFill style={{background:'#10191d'}}>
    {cuts.map((cut, index) => {const from = at; at += cut.seconds * fps; return <Sequence key={index} name={`${index + 1}. ${cut.name}`} from={from} durationInFrames={cut.seconds * fps}><Shot cut={cut}/></Sequence>;})}
    <Audio src={staticFile('media/run-deep-urban.mp3')} trimBefore={15*fps} volume={f => .15 * interpolate(f,[0,30,Math.max(31,duration-90),duration-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence durationInFrames={18}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.018}/></Sequence>
  </AbsoluteFill>;
};

const previewCuts = [plan.cuts[0], plan.cuts[3], plan.cuts[6], plan.cuts[9], plan.cuts[12], plan.cuts[14]].map(cut => ({...cut, seconds:3}));
export const WarmupStrengthCompositions = () => <>
  <Composition id="WarmupStrengthFinal" component={() => <Story cuts={plan.cuts}/>} durationInFrames={total} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="WarmupStrengthPreview" component={() => <Story cuts={previewCuts}/>} durationInFrames={previewCuts.reduce((sum, cut) => sum + cut.seconds * fps, 0)} fps={fps} width={plan.width} height={plan.height}/>
</>;
