import React from 'react';
import {AbsoluteFill, Composition, OffthreadVideo, registerRoot, staticFile} from 'remotion';
import plan from './promise-edit.json';
const PromiseCover: React.FC = () => <AbsoluteFill style={{background: '#10171c', color: '#f5f4ef', fontFamily: 'Arial, Helvetica, sans-serif'}}>
  <OffthreadVideo src={staticFile(plan.source)} muted trimBefore={14745} durationInFrames={1} style={{width: '100%', height: '100%', objectFit: 'cover', filter: plan.grade.looks.fly}} />
  <AbsoluteFill style={{background: 'linear-gradient(90deg,rgba(6,12,17,.96),rgba(6,12,17,.65) 33%,rgba(6,12,17,.08) 62%,transparent 80%)'}} />
  <div style={{position: 'absolute', top: 58, left: 55, fontSize: 16, fontWeight: 700, letterSpacing: 3, color: '#bdc9c5'}}>1% BETTER WITH BIBEK</div>
  <div style={{position: 'absolute', top: 165, left: 55, width: 70, height: 5, background: '#bdc9c5'}} />
  <div style={{position: 'absolute', top: 203, left: 50, fontSize: 87, lineHeight: 1, fontWeight: 900, letterSpacing: -3, textShadow: '0 3px 12px #0008'}}>PROMISE.<br/><span style={{color: '#bdc9c5'}}>KEPT.</span></div>
  <div style={{position: 'absolute', bottom: 60, left: 55, fontSize: 19, fontWeight: 700, letterSpacing: 2}}>UPPER BODY TRAINING</div>
</AbsoluteFill>;
const CoverRoot: React.FC = () => <Composition id="PromiseCover" component={PromiseCover} width={1280} height={720} fps={30} durationInFrames={1} />;
registerRoot(CoverRoot);
