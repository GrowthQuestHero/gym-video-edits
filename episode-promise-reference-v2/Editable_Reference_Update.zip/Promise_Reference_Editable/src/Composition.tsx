import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {clips, fps, height, sourceHasExerciseLabels, sourceHeight, sourceWidth, totalFrames, width} from './short-config';

const source = staticFile('media/finished-long.mp4');
const music = staticFile('media/driving-ambition.mp3');

const VerticalClip: React.FC<{sourceStart: number; seconds: number; centerX: number}> = ({sourceStart, seconds, centerX}) => {
  const scale = height / sourceHeight;
  return <OffthreadVideo src={source} muted trimBefore={sourceStart * fps} durationInFrames={seconds * fps}
    style={{position: 'absolute', top: 0, left: width / 2 - centerX * scale,
      width: sourceWidth * scale, height}} />;
};

// Reused from the Leg Day Short: simple fade and a small vertical rise.
const Title: React.FC<{text: string; duration: number; placement?: 'top' | 'bottom' | 'center'; size?: number}> =
  ({text, duration, placement = 'bottom', size = 73}) => {
    const frame = useCurrentFrame();
    const opacity = interpolate(frame, [0, 12, duration - 12, duration], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
    const rise = interpolate(frame, [0, 15], [18, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
    const place = placement === 'top' ? {justifyContent: 'flex-start', paddingTop: 225} :
      placement === 'center' ? {justifyContent: 'center'} : {justifyContent: 'flex-end', paddingBottom: 280};
    return <AbsoluteFill style={{alignItems: 'center', pointerEvents: 'none', ...place}}>
      <div style={{maxWidth: 890, padding: '18px 28px', color: 'white', whiteSpace: 'pre-line', textAlign: 'center',
        fontFamily: 'Arial, Helvetica, sans-serif', fontWeight: 800, fontSize: size, lineHeight: 1.09,
        letterSpacing: -1.4, textShadow: '0 3px 16px #000, 0 1px 4px #000', opacity,
        transform: `translateY(${rise}px)`}}>{text}</div>
    </AbsoluteFill>;
  };

export const UpperBodyShort: React.FC = () => {
  let at = 0;
  const scenes = clips.map((clip, index) => {
    const from = at;
    at += clip.seconds * fps;
    return <Sequence key={index} from={from} durationInFrames={clip.seconds * fps} name={`${index + 1}. ${clip.name}`}>
      <VerticalClip {...clip} />
    </Sequence>;
  });
  return <AbsoluteFill style={{backgroundColor: '#101415'}}>
    {scenes}
    <Audio src={music} volume={(frame) => interpolate(frame, [0, 24, 1650, 1739], [0, .18, .18, 0],
      {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    <Sequence durationInFrames={90} name="Opening hook"><Title text={'TRAIN SMARTER.\nNOT HARDER.'} duration={90} size={77} /></Sequence>
    {!sourceHasExerciseLabels && <>
      <Sequence from={9 * fps} durationInFrames={90} name="Bench label"><Title text="BENCH PRESS" duration={90} placement="top" size={62} /></Sequence>
      <Sequence from={21 * fps} durationInFrames={90} name="Cable row label"><Title text="CABLE ROW" duration={90} placement="top" size={62} /></Sequence>
      <Sequence from={33 * fps} durationInFrames={90} name="Shoulder press label"><Title text="SHOULDER PRESS" duration={90} placement="top" size={62} /></Sequence>
    </>}
    <Sequence from={53 * fps} durationInFrames={150} name="Closing message"><Title text={'1% BETTER\nEVERY DAY.'} duration={150} placement="bottom" size={82} /></Sequence>
  </AbsoluteFill>;
};

export const MyComposition = () => {
  if (totalFrames !== 1740) throw new Error(`Short must be 1740 frames; got ${totalFrames}`);
  return <Composition id="UpperBodyShort58s" component={UpperBodyShort}
    durationInFrames={totalFrames} fps={fps} width={width} height={height} />;
};
