import React from 'react';
import {AbsoluteFill, Audio, Composition, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import plan from './warmup-strength-short.json';

type Cut=(typeof plan.cuts)[number];
const fps=plan.fps;
const total=plan.cuts.reduce((sum,cut)=>sum+cut.seconds*fps,0);

const Caption:React.FC<{text:string;frames:number}>=({text,frames})=>{
  const f=useCurrentFrame();
  const {width}=useVideoConfig();
  const k=width/1080;
  const opacity=interpolate(f,[0,8,Math.max(9,frames-12),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',padding:`0 ${64*k}px ${335*k}px`,pointerEvents:'none'}}>
    <div style={{width:76*k,height:5*k,background:'#c6d8d0',marginBottom:20*k,opacity}}/>
    <div style={{maxWidth:940*k,color:'#f8f8f3',font:`800 ${text.length>21?57*k:68*k}px Arial, Helvetica, sans-serif`,lineHeight:1.07,textShadow:'0 3px 18px #000',opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot:React.FC<{cut:Cut}>=({cut})=>{
  const {width,height}=useVideoConfig();
  const k=width/1080;
  const w=1380*k,h=776.25*k;
  const left=width/2-cut.centerX*w/1280;
  return <AbsoluteFill style={{overflow:'hidden',background:'#10171c'}}>
    <Img src={staticFile(`media/warmup-short-bg-${cut.section}.jpg`)} style={{width:'100%',height:'100%',objectFit:'cover',filter:'blur(55px) brightness(.28) saturate(.7)',transform:'scale(1.2)'}}/>
    <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(5,10,15,.58),transparent 40%,transparent 62%,rgba(5,10,15,.72))'}}/>
    <div style={{position:'absolute',left,top:(height-h)/2,width:w,height:h,overflow:'hidden',boxShadow:'0 16px 75px rgba(0,0,0,.65)'}}>
      <OffthreadVideo src={staticFile(plan.source)} muted trimBefore={cut.fromSecond*fps} durationInFrames={cut.seconds*fps} style={{width:w,height:h,objectFit:'contain'}}/>
    </div>
    <div style={{position:'absolute',top:210*k,left:64*k,right:64*k,color:'#dfeae5',font:`700 ${34*k}px Arial, Helvetica, sans-serif`,letterSpacing:2.2*k}}>1% BETTER WITH BIBEK</div>
    {cut.caption?<Caption text={cut.caption} frames={cut.seconds*fps}/>:null}
  </AbsoluteFill>;
};

const Story:React.FC<{cuts:Cut[]}>=({cuts})=>{
  let at=0;
  const frames=cuts.reduce((sum,cut)=>sum+cut.seconds*fps,0);
  return <AbsoluteFill style={{background:'#10171c'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.seconds*fps;return <Sequence key={i} name={`${i+1}. ${cut.name}`} from={from} durationInFrames={cut.seconds*fps}><Shot cut={cut}/></Sequence>;})}
    <Audio src={staticFile('media/run-deep-urban.mp3')} trimBefore={22*fps} volume={f=>.16*interpolate(f,[0,15,Math.max(16,frames-75),frames-1],[.55,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence durationInFrames={20}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.018}/></Sequence>
  </AbsoluteFill>;
};

const previewCuts:Cut[]=[plan.cuts[0],plan.cuts[2],plan.cuts[4],plan.cuts[5],plan.cuts[7],plan.cuts[8]].map(c=>({...c,seconds:2}));
export const WarmupStrengthShortCompositions=()=> <>
  <Composition id="WarmupStrengthShort58s" component={()=><Story cuts={plan.cuts}/>} durationInFrames={total} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="WarmupStrengthShortPreview" component={()=><Story cuts={previewCuts}/>} durationInFrames={previewCuts.reduce((sum,c)=>sum+c.seconds*fps,0)} fps={fps} width={360} height={640}/>
</>;
