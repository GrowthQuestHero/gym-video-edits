import React from 'react';
import {AbsoluteFill, Audio, Composition, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export type BrandConfig = {
  channelName: string;
  tagline: string;
  durationFrames: number;
  accentColor: string;
  backgroundColor: string;
  logo?: string;
  backgroundImage?: string;
  footage?: string;
  music?: string;
  soundEffect?: string;
  outroMessage?: string;
  showEndScreenGuides?: boolean;
  socialHandle?: string;
};

const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const font = 'Arial, Helvetica, sans-serif';
const media = (file: string) => file.startsWith('http') ? file : staticFile(file);

const BrandBackground: React.FC<Pick<BrandConfig, 'backgroundColor' | 'backgroundImage' | 'footage'>> = ({backgroundColor, backgroundImage, footage}) => (
  <AbsoluteFill style={{backgroundColor, overflow: 'hidden'}}>
    {footage ? <OffthreadVideo src={media(footage)} muted style={{width: '100%', height: '100%', objectFit: 'cover', opacity: .28}} /> : null}
    {backgroundImage ? <Img src={media(backgroundImage)} style={{width: '100%', height: '100%', objectFit: 'cover', opacity: .25}} /> : null}
    {(footage || backgroundImage) ? <AbsoluteFill style={{background: 'linear-gradient(90deg, rgba(8,14,18,.84), rgba(8,14,18,.54))'}} /> : null}
  </AbsoluteFill>
);

const BrandAudio: React.FC<Pick<BrandConfig, 'durationFrames' | 'music' | 'soundEffect'>> = ({durationFrames, music, soundEffect}) => {
  const {fps} = useVideoConfig();
  const fade = Math.min(12, Math.floor(durationFrames / 5));
  return <>
    {music ? <Audio src={media(music)} volume={(f) => .12 * interpolate(f, [0, fade, durationFrames - fade - 1, durationFrames - 1], [0, 1, 1, 0], clamp)} /> : null}
    {soundEffect ? <Sequence from={3} durationInFrames={Math.min(fps, durationFrames - 3)} premountFor={fps}>
      <Audio src={media(soundEffect)} volume={(f) => .035 * interpolate(f, [0, 4, Math.min(fps - 7, durationFrames - 12), Math.min(fps - 4, durationFrames - 9)], [0, 1, 1, 0], clamp)} />
    </Sequence> : null}
  </>;
};

export const BrandIntro: React.FC<BrandConfig> = (props) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const k = width / 1920;
  const {channelName, tagline, durationFrames, accentColor, backgroundColor, logo, backgroundImage, footage} = props;
  const enter = Math.min(15, Math.floor(durationFrames * .28));
  const leave = Math.max(enter + 1, durationFrames - Math.min(10, Math.floor(durationFrames * .16)));
  const opacity = interpolate(frame, [0, enter, leave, durationFrames - 1], [0, 1, 1, 0], clamp);
  const lineWidth = interpolate(frame, [0, enter, Math.max(enter + 1, durationFrames - 1)], [0, 126, 144], clamp) * k;
  return <AbsoluteFill style={{backgroundColor, color: '#f4f5f0', fontFamily: font}}>
    <BrandBackground backgroundColor={backgroundColor} backgroundImage={backgroundImage} footage={footage} />
    <div style={{position: 'absolute', left: width * .087, top: height * .29, width: width * .82, opacity}}>
      <div style={{height: 6 * k, width: lineWidth, backgroundColor: accentColor, marginBottom: 32 * k}} />
      {logo ? <Img src={media(logo)} style={{maxWidth: 165 * k, maxHeight: 82 * k, objectFit: 'contain', marginBottom: 16 * k}} /> : null}
      <div style={{fontSize: 112 * k, fontWeight: 800, lineHeight: 1.02, letterSpacing: -3.5 * k, maxWidth: '100%', textWrap: 'balance'}}>{channelName}</div>
      <div style={{marginTop: 28 * k, color: accentColor, fontSize: 42 * k, fontWeight: 700, letterSpacing: 1.3 * k}}>{tagline}</div>
    </div>
    <BrandAudio durationFrames={durationFrames} music={props.music} soundEffect={props.soundEffect} />
  </AbsoluteFill>;
};

export const BrandOutro: React.FC<BrandConfig> = (props) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const k = width / 1920;
  const {channelName, durationFrames, accentColor, backgroundColor, logo, backgroundImage, footage, outroMessage = 'Keep getting 1% better.', showEndScreenGuides = false, socialHandle} = props;
  const opacity = interpolate(frame, [0, 15], [0, 1], clamp);
  return <AbsoluteFill style={{backgroundColor, color: '#f4f5f0', fontFamily: font}}>
    <BrandBackground backgroundColor={backgroundColor} backgroundImage={backgroundImage} footage={footage} />
    <div style={{position: 'absolute', left: width * .07, top: height * .13, width: width * .35, opacity}}>
      <div style={{width: 116 * k, height: 6 * k, backgroundColor: accentColor, marginBottom: 30 * k}} />
      {logo ? <Img src={media(logo)} style={{maxWidth: 150 * k, maxHeight: 78 * k, objectFit: 'contain', marginBottom: 14 * k}} /> : null}
      <div style={{fontSize: 73 * k, fontWeight: 800, lineHeight: 1.06, letterSpacing: -2 * k}}>{outroMessage}</div>
      <div style={{marginTop: 37 * k, fontSize: 38 * k, fontWeight: 700, color: accentColor}}>{channelName}</div>
      {socialHandle ? <div style={{marginTop: 13 * k, fontSize: 22 * k, opacity: .8}}>{socialHandle}</div> : null}
    </div>
    {showEndScreenGuides ? <>
      <div style={{position: 'absolute', left: width * .48, top: height * .22, width: width * .37, height: height * .37, border: `3px dashed ${accentColor}`, color: accentColor, display: 'grid', placeItems: 'center', fontSize: 23 * k, opacity: .75}}>NEXT VIDEO GUIDE</div>
      <div style={{position: 'absolute', left: width * .86, top: height * .28, width: 120 * k, height: 120 * k, border: `3px dashed ${accentColor}`, borderRadius: '50%', color: accentColor, display: 'grid', placeItems: 'center', fontSize: 16 * k, opacity: .75}}>SUBSCRIBE GUIDE</div>
    </> : null}
    <div style={{position: 'absolute', left: width * .07, bottom: height * .105, width: width * .86, height: 2 * k, background: accentColor, opacity: .36 * interpolate(frame, [0, 18], [0, 1], clamp)}} />
    <BrandAudio durationFrames={durationFrames} music={props.music} soundEffect={props.soundEffect} />
  </AbsoluteFill>;
};

const sampleFootage = 'media/upper-body-science-source.mp4';
const sampleStart = 68;
const EpisodeShot: React.FC<{seconds: number; fadeOut?: boolean}> = ({seconds, fadeOut = false}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: '#10171b'}}>
    <OffthreadVideo src={staticFile(sampleFootage)} muted trimBefore={Math.round(seconds * fps)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
    {fadeOut ? <AbsoluteFill style={{background: '#0b1216', opacity: interpolate(frame, [51, 59], [0, 1], clamp)}} /> : null}
  </AbsoluteFill>;
};

const introProps: BrandConfig = {channelName: '1% Better with Bibek', tagline: '1% BETTER EVERY DAY.', durationFrames: 75, accentColor: '#a8d0c8', backgroundColor: '#0b1216', soundEffect: 'media/run-small-sweep.wav'};
const outroProps: BrandConfig = {channelName: '1% Better with Bibek', tagline: '1% BETTER EVERY DAY.', durationFrames: 210, accentColor: '#a8d0c8', backgroundColor: '#0b1216', outroMessage: 'Keep getting 1% better.', showEndScreenGuides: false};

export const OpeningDemo: React.FC = () => <AbsoluteFill style={{background: '#0b1216'}}>
  <Sequence durationInFrames={60}><EpisodeShot seconds={sampleStart} fadeOut /></Sequence>
  <Sequence from={60} durationInFrames={75}><BrandIntro {...introProps} /></Sequence>
  <Sequence from={135} durationInFrames={60}><EpisodeShot seconds={sampleStart + 2} /></Sequence>
</AbsoluteFill>;

export const EndingDemo: React.FC = () => <AbsoluteFill style={{background: '#0b1216'}}>
  <Sequence durationInFrames={60}><EpisodeShot seconds={sampleStart + 8} fadeOut /></Sequence>
  <Sequence from={60} durationInFrames={210}><BrandOutro {...outroProps} /></Sequence>
</AbsoluteFill>;

export const BrandCompositions: React.FC = () => <>
  <Composition id="BrandIntro" component={BrandIntro} durationInFrames={75} calculateMetadata={({props}) => ({durationInFrames: props.durationFrames})} fps={30} width={1920} height={1080} defaultProps={{channelName: '1% Better with Bibek', tagline: '1% BETTER EVERY DAY.', durationFrames: 75, accentColor: '#a8d0c8', backgroundColor: '#0b1216', soundEffect: 'media/run-small-sweep.wav'}} />
  <Composition id="BrandIntroShort" component={BrandIntro} durationInFrames={30} calculateMetadata={({props}) => ({durationInFrames: props.durationFrames})} fps={30} width={1920} height={1080} defaultProps={{channelName: '1% Better with Bibek', tagline: '1% BETTER EVERY DAY.', durationFrames: 30, accentColor: '#a8d0c8', backgroundColor: '#0b1216', soundEffect: 'media/run-small-sweep.wav'}} />
  <Composition id="BrandOutro" component={BrandOutro} durationInFrames={210} calculateMetadata={({props}) => ({durationInFrames: props.durationFrames})} fps={30} width={1920} height={1080} defaultProps={{channelName: '1% Better with Bibek', tagline: '1% BETTER EVERY DAY.', durationFrames: 210, accentColor: '#a8d0c8', backgroundColor: '#0b1216', outroMessage: 'Keep getting 1% better.', showEndScreenGuides: false}} />
  <Composition id="BrandOpeningDemo" component={OpeningDemo} durationInFrames={195} fps={30} width={1920} height={1080} />
  <Composition id="BrandEndingDemo" component={EndingDemo} durationInFrames={270} fps={30} width={1920} height={1080} />
</>;
