import {registerRoot} from 'remotion';
import {PromiseReferenceCompositions} from './PromiseReferenceReplacement';
registerRoot(PromiseReferenceCompositions);
