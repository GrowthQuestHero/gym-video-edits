import React from 'react';
import {AbsoluteFill, Audio, Composition, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import plan from './upper-ice-short.json';

type Cut=(typeof plan.cuts)[number];
const fps=plan.fps;
const source=staticFile(plan.source);
const total=plan.cuts.reduce((n,c)=>n+c.seconds*fps,0);

const Caption:React.FC<{text:string;frames:number}>=({text,frames})=>{
  const f=useCurrentFrame();
  const {width}=useVideoConfig();
  const k=width/1080;
  const opacity=interpolate(f,[0,8,Math.max(9,frames-10),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',padding:`0 ${64*k}px ${340*k}px`,pointerEvents:'none'}}>
    <div style={{width:75*k,height:5*k,background:'#c5d8d1',marginBottom:20*k,opacity}}/>
    <div style={{maxWidth:930*k,color:'#f8f8f3',font:`800 ${text.length>22?57*k:69*k}px Arial, Helvetica, sans-serif`,lineHeight:1.06,textShadow:'0 3px 18px #000',opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot:React.FC<{cut:Cut}>=({cut})=>{
  const {width,height}=useVideoConfig();
  const k=width/1080;
  const w=1500*k,h=843.75*k;
  const left=width/2-cut.centerX*w/1280;
  const still=staticFile(`media/upper-ice-short-bg-${cut.section}.jpg`);
  return <AbsoluteFill style={{overflow:'hidden',background:'#10161d'}}>
    <Img src={still} style={{width:'100%',height:'100%',objectFit:'cover',filter:'blur(56px) brightness(.3) saturate(.73)',transform:'scale(1.2)'}}/>
    <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(4,9,14,.55),transparent 36%,transparent 68%,rgba(4,9,14,.67))'}}/>
    <div style={{position:'absolute',left,top:(height-h)/2,width:w,height:h,overflow:'hidden',boxShadow:'0 16px 75px rgba(0,0,0,.65)'}}>
      <OffthreadVideo src={source} muted trimBefore={cut.fromSecond*fps} durationInFrames={cut.seconds*fps} style={{width:w,height:h,objectFit:'contain'}}/>
    </div>
    <div style={{position:'absolute',top:205*k,left:64*k,right:64*k,color:'#e4ece8',font:`700 ${33*k}px Arial, Helvetica, sans-serif`,letterSpacing:2.3*k}}>1% BETTER WITH BIBEK</div>
    {cut.caption?<Caption text={cut.caption} frames={cut.seconds*fps}/>:null}
  </AbsoluteFill>;
};

const Story:React.FC<{cuts:Cut[]}>=({cuts})=>{
  let at=0;
  const frames=cuts.reduce((n,c)=>n+c.seconds*fps,0);
  const bathAt=Math.max(0,frames-15*fps);
  return <AbsoluteFill style={{background:'#10161d'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.seconds*fps;return <Sequence key={i} name={`${i+1}. ${cut.name}`} from={from} durationInFrames={cut.seconds*fps}><Shot cut={cut}/></Sequence>;})}
    <Audio src={staticFile('media/run-deep-urban.mp3')} trimBefore={20*fps} volume={f=>.16*interpolate(f,[0,15,Math.max(16,bathAt-25),bathAt+65],[.55,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence from={bathAt} durationInFrames={frames-bathAt}><Audio src={staticFile('media/run-new-life.mp3')} trimBefore={28*fps} volume={f=>.12*interpolate(f,[0,55,Math.max(56,frames-bathAt-55),frames-bathAt-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/></Sequence>
    <Sequence durationInFrames={22}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.02}/></Sequence>
    <Sequence from={bathAt} durationInFrames={22}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.018}/></Sequence>
  </AbsoluteFill>;
};

const previewCuts:Cut[]=[plan.cuts[0],plan.cuts[2],plan.cuts[4],plan.cuts[5],plan.cuts[8],plan.cuts[9]].map(c=>({...c,seconds:2}));
export const UpperIceShortCompositions=()=> <>
  <Composition id="UpperIceShort58s" component={()=><Story cuts={plan.cuts}/>} durationInFrames={total} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="UpperIceShortPreview" component={()=><Story cuts={previewCuts}/>} durationInFrames={previewCuts.reduce((n,c)=>n+c.seconds*fps,0)} fps={fps} width={360} height={640}/>
</>;
