import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import plan from './the-days-edit.json';

type Cut = (typeof plan.cuts)[number];
const fps = plan.fps;
const source = staticFile(plan.source);
const music = staticFile('media/run-deep-urban.mp3');
const sweep = staticFile('media/run-small-sweep.wav');
const total = plan.cuts.reduce((sum, cut) => sum + Math.round(cut.seconds * fps), 0);

const Label: React.FC<{text: string; duration: number}> = ({text, duration}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [0, 9, Math.max(10, duration - 12), duration - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'flex-start', padding: '0 50px 48px', pointerEvents: 'none'}}>
    <div style={{background: 'rgba(8,14,20,.65)', borderLeft: '4px solid #bcc9c4', padding: '10px 17px', color: '#f6f6f0', font: '800 34px Arial, Helvetica, sans-serif', letterSpacing: 1.1, textShadow: '0 2px 9px #000', opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot: React.FC<{cut: Cut; index: number}> = ({cut, index}) => {
  const frame = useCurrentFrame();
  const frames = Math.round(cut.seconds * fps);
  const filter = plan.looks[cut.section as keyof typeof plan.looks];
  return <AbsoluteFill style={{background: '#111820', overflow: 'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={Math.round(cut.sourceStart * fps)} durationInFrames={frames} style={{width: '100%', height: '100%', objectFit: 'cover', filter, transform: index === 0 ? `scale(${1 + .012 * frame / frames})` : undefined}} />
    {cut.caption ? <Sequence from={Math.min(12, frames - 1)} durationInFrames={Math.min(100, frames - 12)}><Label text={cut.caption} duration={Math.min(100, frames - 12)} /></Sequence> : null}
  </AbsoluteFill>;
};

const Story: React.FC<{cuts: Cut[]}> = ({cuts}) => {
  const duration = cuts.reduce((sum, cut) => sum + Math.round(cut.seconds * fps), 0);
  let at = 0;
  return <AbsoluteFill style={{background: '#111820'}}>
    {cuts.map((cut, index) => {
      const from = at;
      at += Math.round(cut.seconds * fps);
      return <Sequence key={index} name={`${index + 1}. ${cut.name}`} from={from} durationInFrames={Math.round(cut.seconds * fps)}><Shot cut={cut} index={index} /></Sequence>;
    })}
    <Audio src={music} volume={(f) => .16 * interpolate(f, [0, 36, Math.max(37, duration - 60), duration - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    <Sequence durationInFrames={24}><Audio src={sweep} volume={.018} /></Sequence>
  </AbsoluteFill>;
};

const previewCuts = [plan.cuts[0], plan.cuts[2], plan.cuts[6], plan.cuts[10], plan.cuts[14], plan.cuts[15]].map(cut => ({...cut, seconds: Math.min(cut.seconds, 3)}));
export const TheDaysCompositions = () => <>
  <Composition id="TheDaysNobodySeesFinal" component={() => <Story cuts={plan.cuts} />} durationInFrames={total} fps={fps} width={plan.width} height={plan.height} />
  <Composition id="TheDaysNobodySeesPreview" component={() => <Story cuts={previewCuts} />} durationInFrames={previewCuts.reduce((sum, cut) => sum + Math.round(cut.seconds * fps), 0)} fps={fps} width={plan.width} height={plan.height} />
</>;
