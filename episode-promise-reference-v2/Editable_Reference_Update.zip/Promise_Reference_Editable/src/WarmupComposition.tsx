import React from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {warmupCaptions,warmupCuts,warmupDuration,warmupFps,warmupFrames,type WarmupCut,type WarmupSection} from './warmup-config';

const source=staticFile('media/warmup-source.mp4');
const grade:Record<WarmupSection,string>={
  hook:'brightness(1.02) contrast(1.035) saturate(.87)',
  arms:'brightness(1.055) contrast(1.025) saturate(.89)',
  triceps:'brightness(1.05) contrast(1.025) saturate(.89)',
  wrists:'brightness(1.055) contrast(1.025) saturate(.89)',
  legs:'brightness(1.025) contrast(1.025) saturate(.86)',
  lunge:'brightness(1.02) contrast(1.025) saturate(.86)',
  floor:'brightness(1.01) contrast(1.025) saturate(.86)',
  kneel:'brightness(1.01) contrast(1.025) saturate(.86)',
  hamstring:'brightness(1.01) contrast(1.025) saturate(.86)',
  back:'brightness(1.015) contrast(1.025) saturate(.86)',
  cardio:'brightness(1.04) contrast(1.025) saturate(.89)',
  ending:'brightness(1.04) contrast(1.025) saturate(.89)',
};

// The supplied recording has baked-in claims and misspelled labels.
// Replacing their text areas with verified labels leaves the source untouched.
const masks:Partial<Record<WarmupSection,{left:number;top:number;width:number;height:number;title:string}>>={
  hook:{left:785,top:275,width:495,height:105,title:'SIDE LUNGE'},
  arms:{left:830,top:135,width:450,height:95,title:'ARM CIRCLES'},
  triceps:{left:800,top:130,width:480,height:95,title:'OVERHEAD STRETCH'},
  wrists:{left:820,top:60,width:460,height:95,title:'WRIST MOVEMENT'},
  legs:{left:785,top:275,width:495,height:105,title:'LEG STRETCH'},
  lunge:{left:785,top:275,width:495,height:105,title:'SIDE LUNGE'},
  floor:{left:730,top:45,width:550,height:100,title:'FLOOR MOBILITY'},
  kneel:{left:565,top:215,width:715,height:105,title:'KNEELING STRETCH'},
  hamstring:{left:565,top:210,width:715,height:115,title:'HAMSTRING STRETCH'},
  back:{left:660,top:205,width:620,height:105,title:'BACK EXTENSION'},
  cardio:{left:945,top:135,width:335,height:100,title:'TREADMILL'},
};

const Shot:React.FC<WarmupCut>=({sourceStart,seconds,section})=>{
  const mask=masks[section];
  const {width,height}=useVideoConfig();
  const k=width/1280;
  return <AbsoluteFill style={{background:'#111819'}}>
    <OffthreadVideo src={source} muted trimBefore={sourceStart*warmupFps} durationInFrames={seconds*warmupFps}
      style={{width,height,filter:grade[section]}}/>
    {mask&&<div style={{position:'absolute',left:mask.left*k,top:mask.top*k,width:mask.width*k,height:mask.height*k,
      background:'rgba(17,25,28,.96)',borderLeft:`${5*k}px solid #a8d0c8`,boxSizing:'border-box',
      display:'flex',alignItems:'center',paddingLeft:26*k,color:'#f5f6f2',
      font:`800 ${27*k}px Arial, Helvetica, sans-serif`,letterSpacing:1*k}}>{mask.title}</div>}
  </AbsoluteFill>;
};

const Caption:React.FC<{text:string;frames:number}>=({text,frames})=>{
  const f=useCurrentFrame();
  const {width}=useVideoConfig();
  const k=width/1280;
  const opacity=interpolate(f,[0,9,Math.max(10,frames-10),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const rise=interpolate(f,[0,12],[10,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{pointerEvents:'none',padding:`${64*k}px ${60*k}px`,background:'linear-gradient(180deg,rgba(4,9,12,.42),transparent 33%)'}}>
    <div style={{width:90*k,height:5*k,marginBottom:17*k,background:'#a8d0c8',opacity}}/>
    <div style={{maxWidth:780*k,font:`800 ${45*k}px Arial, Helvetica, sans-serif`,lineHeight:1.08,letterSpacing:-.5*k,
      color:'#f5f6f2',textShadow:'0 3px 13px #000',opacity,transform:`translateY(${rise*k}px)`}}>{text}</div>
  </AbsoluteFill>;
};

const Soundtrack:React.FC<{duration:number}>=({duration})=><>
  <Audio src={staticFile('media/run-discover.mp3')}
    volume={f=>interpolate(f,[0,28,Math.max(29,(duration-4)*warmupFps),duration*warmupFps-1],
      [0,.15,.15,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
  <Sequence durationInFrames={32}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.025}/></Sequence>
  {duration>120&&<Sequence from={120*warmupFps} durationInFrames={32}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.025}/></Sequence>}
</>;

export const WarmupStory:React.FC=()=>{
  let at=0;
  return <AbsoluteFill style={{background:'#111819'}}>
    {warmupCuts.map((cut,i)=>{const from=at;at+=cut.seconds*warmupFps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*warmupFps} name={`${i+1}: ${cut.name}`}><Shot {...cut}/></Sequence>})}
    <Soundtrack duration={warmupDuration}/>
    {warmupCaptions.map((c,i)=><Sequence key={i} from={c.from*warmupFps} durationInFrames={c.seconds*warmupFps} name={`Caption: ${c.text}`}>
      <Caption text={c.text} frames={c.seconds*warmupFps}/>
    </Sequence>)}
  </AbsoluteFill>;
};

const previewCuts=[warmupCuts[0],warmupCuts[2],warmupCuts[6],warmupCuts[9],warmupCuts[12],warmupCuts[13]];
export const WarmupPreview:React.FC=()=>{
  let at=0;
  const short=previewCuts.map((cut,i)=>({...cut,seconds:i===5?3:4}));
  return <AbsoluteFill style={{background:'#111819'}}>
    {short.map((cut,i)=>{const from=at;at+=cut.seconds*warmupFps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*warmupFps}><Shot {...cut}/></Sequence>})}
    <Soundtrack duration={23}/>
    {[{from:0,text:'WORKOUT SURU HUNU AGADI...'},{from:5,text:'PREPARATION MATTERS.'},
      {from:13,text:'MOVEMENT FIRST.'},{from:20,text:'1% BETTER EVERY DAY.'}]
      .map((c,i)=><Sequence key={i} from={c.from*warmupFps} durationInFrames={3*warmupFps}><Caption text={c.text} frames={3*warmupFps}/></Sequence>)}
  </AbsoluteFill>;
};

export const WarmupCompositions=()=> <>
  <Composition id="WarmupCinematicFinal" component={WarmupStory} durationInFrames={warmupFrames} fps={warmupFps} width={1280} height={720}/>
  <Composition id="WarmupCinematicPreview" component={WarmupPreview} durationInFrames={23*warmupFps} fps={warmupFps} width={640} height={360}/>
</>;
