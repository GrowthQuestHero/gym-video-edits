import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile} from 'remotion';
import {PromiseFinal as OriginalVisual} from './PromiseReferenceVisual';
import original from './promise-edit.json';
import revision from './promise-reference-edit.json';

const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
type Segment = (typeof revision.segments)[number];

// Reuses the original track trims, gains, and envelopes at their original times.
// Only the short bed fades at the replacement boundaries are new.
const OriginalMusicSection: React.FC<{originalStart: number; frames: number}> = ({originalStart, frames}) => <>
  {original.audio.music.map((m) => <Sequence key={m.file} from={m.fromFrame - originalStart} durationInFrames={m.durationFrames}>
    <Audio src={staticFile(m.file)} trimBefore={m.trimBefore} volume={(f) => {
      const originalEnvelope = interpolate(f, [0, m.fromFrame === 0 ? 30 : 60, m.durationFrames - (m.fromFrame === 0 ? 60 : 100), m.durationFrames - 1], [0, 1, 1, 0], clamp);
      const sectionFrame = f + m.fromFrame - originalStart;
      const endFade = interpolate(sectionFrame, [frames - revision.bedBoundaryFadeFrames - 1, frames - 1], [1, 0], clamp);
      const startFade = originalStart === 0 ? 1 : interpolate(sectionFrame, [0, revision.bedBoundaryFadeFrames], [0, 1], clamp);
      return m.gain * originalEnvelope * startFade * endFade;
    }} />
  </Sequence>)}
</>;

const SegmentContent: React.FC<{segment: Segment}> = ({segment}) => {
  if (segment.kind === 'reference') {
    return <AbsoluteFill style={{background: '#000'}}>
      <OffthreadVideo src={staticFile(segment.asset!)} trimBefore={0} durationInFrames={segment.frames} volume={1} playbackRate={1}
        style={{width: '100%', height: '100%', objectFit: 'contain'}} />
    </AbsoluteFill>;
  }
  return <AbsoluteFill>
    <Sequence from={-segment.originalStart!} durationInFrames={original.totalFrames}>
      <OriginalVisual />
    </Sequence>
    <OriginalMusicSection originalStart={segment.originalStart!} frames={segment.frames} />
  </AbsoluteFill>;
};

export const PromiseReferenceFinal: React.FC = () => <AbsoluteFill style={{background: '#10171c'}}>
  {revision.segments.map((s) => <Sequence key={s.name} from={s.fromFrame} durationInFrames={s.frames} name={s.name}>
    <SegmentContent segment={s} />
  </Sequence>)}
</AbsoluteFill>;

export const PromiseReferencePreview: React.FC = () => {
  let at = 0;
  return <AbsoluteFill>
    {revision.previewWindows.map((w) => {
      const from = at; at += w.frames;
      return <Sequence key={w.from} from={from} durationInFrames={w.frames}>
        <Sequence from={-w.from} durationInFrames={revision.totalFrames}><PromiseReferenceFinal /></Sequence>
      </Sequence>;
    })}
  </AbsoluteFill>;
};

export const PromiseReferenceCompositions: React.FC = () => <>
  <Composition id="PromiseReferenceFinal" component={PromiseReferenceFinal} width={revision.width} height={revision.height} fps={revision.fps} durationInFrames={revision.totalFrames} />
  <Composition id="PromiseReferencePreview" component={PromiseReferencePreview} width={revision.width} height={revision.height} fps={revision.fps} durationInFrames={revision.previewWindows.reduce((n, w) => n + w.frames, 0)} />
</>;
