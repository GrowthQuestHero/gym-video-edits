import {registerRoot} from 'remotion';
import {PromiseCompositions} from './PromiseEpisode';
registerRoot(PromiseCompositions);
