// Verified source ranges reused from warmup-config.ts and the finished long edit.
// The 3-second hook previews a later side lunge; the remaining shots are chronological.
export type WarmupShortCut={sourceStart:number;seconds:number;centerX:number;fill:number;section:'hook'|'arms'|'triceps'|'wrists'|'lunge'|'floor'|'hamstring'|'back'|'cardio'|'ending';name:string};
export const warmupShortFps=30;
export const warmupShortCuts:WarmupShortCut[]=[
  {sourceStart:65,seconds:3,centerX:500,fill:.85,section:'hook',name:'Movement hook'},
  {sourceStart:12,seconds:5,centerX:650,fill:1,section:'arms',name:'Preparation and arm movement'},
  {sourceStart:18,seconds:6,centerX:650,fill:1,section:'arms',name:'Arm circles'},
  {sourceStart:30,seconds:5,centerX:650,fill:1,section:'triceps',name:'Overhead arm stretch'},
  {sourceStart:40,seconds:5,centerX:620,fill:1,section:'wrists',name:'Wrist movement'},
  {sourceStart:63,seconds:6,centerX:500,fill:.85,section:'lunge',name:'Side lunge'},
  {sourceStart:83,seconds:6,centerX:470,fill:1,section:'floor',name:'Floor mobility'},
  {sourceStart:109,seconds:6,centerX:410,fill:1,section:'hamstring',name:'Lower-body stretch'},
  {sourceStart:136,seconds:6,centerX:405,fill:1,section:'back',name:'Back extension'},
  {sourceStart:152,seconds:5,centerX:650,fill:1,section:'cardio',name:'Treadmill warm-up'},
  {sourceStart:164,seconds:2,centerX:650,fill:1,section:'cardio',name:'Final treadmill moment'},
  {sourceStart:173,seconds:3,centerX:530,fill:1,section:'ending',name:'Closing moment'},
];
export const warmupShortFrames=warmupShortCuts.reduce((sum,c)=>sum+c.seconds*warmupShortFps,0);
if(warmupShortFrames!==1740)throw new Error(`Warm-up Short must be 1740 frames; got ${warmupShortFrames}`);
export const warmupShortCaptions=[
  {from:0,seconds:3,text:'WORKOUT SURU HUNU AGADI...'},
  {from:3,seconds:4,text:'PREPARATION MATTERS.'},
  {from:11,seconds:3,text:'PAHILA, MOBILITY.'},
  {from:25,seconds:4,text:'MOVEMENT FIRST.'},
  {from:48,seconds:4,text:'BODY READY GARA.'},
  {from:53,seconds:2,text:'READY TO TRAIN.'},
  {from:55,seconds:3,text:'1% BETTER EVERY DAY.'},
];
