// Visual-only derivative; Caption and Shot are byte-identical to the preserved original.
import React from 'react';
import {AbsoluteFill, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {BrandIntro, BrandOutro} from './BrandSequences';
import plan from './promise-edit.json';

// Adapted from the existing UpperBodyScienceComposition Shot/Caption/Soundtrack
// and WarmupStrengthShort's inset framing. Original components remain untouched.
type Cut = (typeof plan.cuts)[number];
const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const brand = {channelName: '1% Better with Bibek', tagline: 'ONE SESSION AT A TIME.', accentColor: '#bdc9c5', backgroundColor: '#10171c'};
const titles: Record<string, string> = {bench: 'Barbell\nbench press', incline: 'Incline\ndumbbell press', flat: 'Dumbbell\npress', shoulder: 'Seated\nshoulder press', fly: 'Machine\nfly', cable: 'Cable\npressdown'};
const Caption: React.FC<{text: string; duration: number}> = ({text, duration}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 9, Math.max(10, duration - 12), duration - 1], [0, 1, 1, 0], clamp);
  const rise = interpolate(frame, [0, 12], [9, 0], clamp);
  return <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'flex-start', padding: '0 50px 43px', pointerEvents: 'none'}}>
    <div style={{width: 60, height: 3, background: '#bdc9c5', marginBottom: 12, opacity}} />
    <div style={{maxWidth: 760, padding: '9px 14px', background: 'rgba(7,12,18,.68)', color: '#f5f4ef', font: '800 28px Arial, Helvetica, sans-serif', lineHeight: 1.13, letterSpacing: 1, opacity, transform: `translateY(${rise}px)`}}>{text}</div>
  </AbsoluteFill>;
};

const Shot: React.FC<{cut: Cut}> = ({cut}) => {
  const frame = useCurrentFrame();
  const filter = plan.grade.looks[cut.section as keyof typeof plan.grade.looks];
  const videoStyle: React.CSSProperties = cut.layout === 'square'
    ? {position: 'absolute', width: 1280 * 640 / 720, height: 640, left: -280 * 640 / 720, top: 0, filter}
    : {width: '100%', height: '100%', objectFit: 'cover', filter};
  return <AbsoluteFill style={{background: '#10171c', overflow: 'hidden'}}>
    {cut.layout === 'square' ? <>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 85% 30%,#20312f 0%,#10171c 65%)'}} />
      <div style={{position: 'absolute', left: 53, top: 190, width: 430, color: '#f5f4ef', fontFamily: 'Arial, Helvetica, sans-serif'}}>
        <div style={{color: '#bdc9c5', fontSize: 17, fontWeight: 700, letterSpacing: 3, marginBottom: 26}}>{cut.chapter}</div>
        <div style={{width: 60, height: 3, background: '#bdc9c5', marginBottom: 23}} />
        <div style={{whiteSpace: 'pre-line', fontSize: 44, lineHeight: 1.12, fontWeight: 800, letterSpacing: -1}}>{titles[cut.section]}</div>
        <div style={{marginTop: 38, fontSize: 12, letterSpacing: 2, color: '#a5b5b1'}}>1% BETTER WITH BIBEK</div>
      </div>
      <div style={{position: 'absolute', top: 40, left: 550, width: 640, height: 640, overflow: 'hidden', boxShadow: '0 14px 50px #0008', border: '1px solid #53625b'}}>
        <OffthreadVideo src={staticFile(plan.source)} muted trimBefore={cut.sourceStartFrame ?? 0} durationInFrames={cut.durationFrames} style={videoStyle} />
      </div>
    </> : <>
      <OffthreadVideo src={staticFile(plan.source)} muted trimBefore={cut.sourceStartFrame ?? 0} durationInFrames={cut.durationFrames} style={videoStyle} />
      {cut.caption && cut.role !== 'hook' ? <Sequence from={12} durationInFrames={105}><Caption text={cut.caption} duration={105} /></Sequence> : null}
    </>}
    {cut.role === 'hook' ? <AbsoluteFill style={{background: 'linear-gradient(90deg,rgba(6,12,17,.9) 0%,rgba(6,12,17,.55) 38%,transparent 72%)', padding: '124px 55px', color: '#f5f4ef', fontFamily: 'Arial, Helvetica, sans-serif'}}>
      <div style={{fontSize: 14, fontWeight: 700, letterSpacing: 3.5, color: '#bdc9c5', marginBottom: 26}}>1% BETTER WITH BIBEK</div>
      <div style={{width: 65, height: 3, background: '#bdc9c5', marginBottom: 24}} />
      <div style={{fontSize: 56, fontWeight: 800, lineHeight: 1.04, letterSpacing: -1.5}}>A PROMISE.<br/>ONE SESSION.</div>
      <div style={{fontSize: 17, letterSpacing: 2, color: '#d4dfd9', marginTop: 26}}>UPPER BODY TRAINING</div>
      <div style={{position: 'absolute', bottom: 35, left: 55, color: '#d4dfd9', fontSize: 11, letterSpacing: 2}}>OPENING EXCERPT · SESSION EDIT FOLLOWS</div>
    </AbsoluteFill> : null}
    {cut.role === 'closing' ? <AbsoluteFill style={{background: '#10171c', opacity: interpolate(frame, [cut.durationFrames - 30, cut.durationFrames - 1], [0, 1], clamp)}} /> : null}
  </AbsoluteFill>;
};

export const PromiseFinal: React.FC = () => <AbsoluteFill style={{background: '#10171c'}}>
  {plan.cuts.map((cut) => <Sequence key={cut.id} from={cut.timelineStartFrame} durationInFrames={cut.durationFrames} name={`${cut.id}. ${cut.name}`}>
    {cut.role === 'intro' ? <BrandIntro {...brand} durationFrames={cut.durationFrames} /> : cut.role === 'outro' ? <BrandOutro {...brand} durationFrames={cut.durationFrames} outroMessage={'One session.\nAnother step.'} /> : <Shot cut={cut} />}
  </Sequence>)}
</AbsoluteFill>;

// Each window seeks the exact final composition, including its soundtrack envelope.
export const PromisePreview: React.FC = () => {
  let at = 0;
  return <AbsoluteFill>
    {plan.previewWindows.map((w, i) => {
      const start = at; at += w.frames;
      return <Sequence key={w.from} from={start} durationInFrames={w.frames}>
        <Sequence from={-w.from} durationInFrames={plan.totalFrames}><PromiseFinal /></Sequence>
        <div style={{position: 'absolute', right: 12, top: 10, padding: '5px 8px', background: '#10171ccc', color: '#f5f4ef', font: '11px Arial', letterSpacing: 1}}>QC SAMPLE {i + 1}/5</div>
      </Sequence>;
    })}
  </AbsoluteFill>;
};

export const PromiseCompositions: React.FC = () => <>
  <Composition id="PromiseEpisodeFinal" component={PromiseFinal} durationInFrames={plan.totalFrames} fps={plan.fps} width={plan.width} height={plan.height} />
  <Composition id="PromiseEpisodePreview" component={PromisePreview} durationInFrames={plan.previewWindows.reduce((n, w) => n + w.frames, 0)} fps={plan.fps} width={plan.width} height={plan.height} />
</>;
