export type RunSection='hook'|'establish'|'warmup'|'prepare'|'run'|'pause'|'side'|'stop'|'recover'|'ending';
export type RunCut={sourceStart:number;duration:number;section:RunSection;name:string};

// Verified timecodes from the single 5:48.18 source recording. The hook previews
// later running footage; the remaining cuts follow the source chronology.
export const runCuts:RunCut[]=[
  {sourceStart:200,duration:8,section:'hook',name:'Running hook'},
  {sourceStart:0,duration:8,section:'establish',name:'Gym establishing shot'},
  {sourceStart:22,duration:18,section:'warmup',name:'Dynamic warm-up'},
  {sourceStart:49,duration:8,section:'prepare',name:'Water and preparation'},
  {sourceStart:60,duration:25,section:'run',name:'Treadmill start'},
  {sourceStart:90,duration:25,section:'run',name:'First running stretch'},
  {sourceStart:116,duration:14,section:'run',name:'Continuing at treadmill'},
  {sourceStart:132,duration:8,section:'pause',name:'Water pause'},
  {sourceStart:152,duration:23,section:'side',name:'Side-angle running begins'},
  {sourceStart:180,duration:19,section:'side',name:'Side-angle running continues'},
  {sourceStart:210,duration:18,section:'side',name:'Later running stretch'},
  {sourceStart:230,duration:16,section:'side',name:'Final running stretch'},
  {sourceStart:250,duration:12,section:'stop',name:'Run ends'},
  {sourceStart:300,duration:12,section:'recover',name:'Recovery at treadmill'},
  {sourceStart:335,duration:10,section:'ending',name:'Closing moment'},
];
export const runDuration=runCuts.reduce((sum,c)=>sum+c.duration,0);
export const runFps=30;
