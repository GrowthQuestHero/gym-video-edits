import React from 'react';
import {AbsoluteFill, Audio, Composition, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import plan from './upper-body-short-v2.json';

type Cut = (typeof plan.cuts)[number];
type CaptionCue = (typeof plan.captions)[number];
const fps = 30;
const shotPath = (number: number) => staticFile(`media/upper-body-science-v2/shot_${String(number).padStart(2, '0')}.mp4`);
const bgPath = (number: number) => staticFile(`media/upper-body-short-v2-bg/shot_${String(number).padStart(2, '0')}.jpg`);

const Shot: React.FC<{cut: Cut}> = ({cut}) => {
  const {width, height} = useVideoConfig();
  const k = width / 1080;
  const wide = cut.layout === 'wide';
  const s = wide ? cut.scale * k : height / 720;
  const w = 1280 * s;
  const h = 720 * s;
  const left = width / 2 - cut.centerX * s;
  const top = wide ? (height - h) / 2 : 0;
  return <AbsoluteFill style={{background: '#101820', overflow: 'hidden'}}>
    {wide && <>
      <Img src={bgPath(cut.longShot)} style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(44px) brightness(.34) saturate(.72)', transform: 'scale(1.12)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(to bottom,rgba(4,9,14,.38),transparent 40%,transparent 66%,rgba(4,9,14,.45))'}} />
    </>}
    <div style={{position: 'absolute', width: w, height: h, left, top, overflow: 'hidden', boxShadow: wide ? '0 20px 75px #000a' : 'none'}}>
      <OffthreadVideo src={shotPath(cut.longShot)} trimBefore={cut.trimFrames} muted style={{width: w, height: h}} />
    </div>
  </AbsoluteFill>;
};

const Caption: React.FC<{cue: CaptionCue}> = ({cue}) => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const k = width / 1080;
  const opacity = interpolate(frame, [0, 8, Math.max(9, cue.durationFrames - 10), cue.durationFrames - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rise = interpolate(frame, [0, 12], [15, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const bottom = cue.position === 'bottom';
  return <AbsoluteFill style={{justifyContent: bottom ? 'flex-end' : 'flex-start', alignItems: 'flex-start', padding: bottom ? `0 ${74*k}px ${270*k}px` : `${205*k}px ${74*k}px 0`, pointerEvents: 'none'}}>
    <div style={{padding: `${12*k}px ${15*k}px`, background: 'rgba(4,9,14,.56)', borderLeft: `${5*k}px solid #bad5d2`, opacity, transform: `translateY(${rise*k}px)`, maxWidth: 920*k}}>
      <span style={{color: '#f7f7f2', font: `800 ${cue.text.length > 19 ? 57*k : 68*k}px Arial, Helvetica, sans-serif`, letterSpacing: .4*k, lineHeight: 1.06, textShadow: '0 2px 11px #000b'}}>{cue.text}</span>
    </div>
  </AbsoluteFill>;
};

const Soundtrack: React.FC<{duration: number; transition: number}> = ({duration, transition}) => {
  const endStart = duration - 10*fps;
  return <>
    <Audio src={staticFile(plan.music.main)} trimBefore={20*fps} volume={f => plan.music.mainVolume * interpolate(f, [0, 12, endStart, endStart + 70], [.75, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    <Sequence from={endStart} durationInFrames={10*fps}>
      <Audio src={staticFile(plan.music.ending)} trimBefore={30*fps} volume={f => plan.music.endingVolume * interpolate(f, [0, 55, 240, 299], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    </Sequence>
    <Sequence durationInFrames={26}><Audio src={staticFile(plan.music.sfx)} volume={.035} /></Sequence>
    <Sequence from={transition} durationInFrames={26}><Audio src={staticFile(plan.music.sfx)} volume={.025} /></Sequence>
  </>;
};

const Story: React.FC<{cuts: Cut[]; captions: CaptionCue[]; duration: number; transition: number}> = ({cuts, captions, duration, transition}) => {
  let cursor = 0;
  return <AbsoluteFill style={{background: '#101820'}}>
    {cuts.map((cut, i) => {const from = cursor; cursor += cut.durationFrames; return <Sequence key={i} from={from} durationInFrames={cut.durationFrames} name={`${i+1}. ${cut.name}`}><Shot cut={cut}/></Sequence>;})}
    <Soundtrack duration={duration} transition={transition} />
    {captions.map((cue, i) => <Sequence key={i} from={cue.fromFrame} durationInFrames={cue.durationFrames} name={cue.text}><Caption cue={cue}/></Sequence>)}
  </AbsoluteFill>;
};

const previewIndices = [0, 2, 4, 5, 8, 11];
const previewCuts: Cut[] = previewIndices.map(i => ({...plan.cuts[i], trimFrames: plan.cuts[i].trimFrames, durationFrames: 90}));
const previewCaptions: CaptionCue[] = [
  {fromFrame: 0, durationFrames: 85, text: 'TRAIN SMARTER.', position: 'top'},
  {fromFrame: 90, durationFrames: 85, text: 'BENCH PRESS', position: 'bottom'},
  {fromFrame: 180, durationFrames: 85, text: 'LATERAL RAISES', position: 'bottom'},
  {fromFrame: 270, durationFrames: 85, text: 'TRICEP PUSHDOWNS', position: 'top'},
  {fromFrame: 360, durationFrames: 85, text: 'TESPACHI, TREADMILL.', position: 'top'},
  {fromFrame: 450, durationFrames: 89, text: '1% BETTER EVERY DAY.', position: 'bottom'}
];

export const UpperBodyShortV2: React.FC = () => <Story cuts={plan.cuts} captions={plan.captions} duration={1740} transition={1170} />;
export const UpperBodyShortV2Preview: React.FC = () => <Story cuts={previewCuts} captions={previewCaptions} duration={540} transition={360} />;
export const UpperBodyShortV2Compositions = () => <>
  <Composition id="UpperBodyShortV2-58s" component={UpperBodyShortV2} durationInFrames={1740} fps={fps} width={1080} height={1920} />
  <Composition id="UpperBodyShortV2-Preview" component={UpperBodyShortV2Preview} durationInFrames={540} fps={fps} width={360} height={640} />
</>;
