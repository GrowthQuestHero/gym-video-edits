export type Clip = {sourceStart: number; seconds: number; centerX: number; name: string};

// Source times are in the finished Upper Body long video, not the raw recording.
// A future Short can reuse this composition by replacing these verified ranges.
export const clips: Clip[] = [
  {sourceStart: 213, seconds: 3, centerX: 640, name: 'Shoulder-press hook'},
  {sourceStart: 6, seconds: 6, centerX: 640, name: 'Warm-up'},
  {sourceStart: 18, seconds: 6, centerX: 640, name: 'Bench press one'},
  {sourceStart: 78, seconds: 6, centerX: 640, name: 'Bench press two'},
  {sourceStart: 120, seconds: 6, centerX: 640, name: 'Cable row one'},
  {sourceStart: 170, seconds: 6, centerX: 640, name: 'Cable row two'},
  {sourceStart: 221, seconds: 6, centerX: 640, name: 'Shoulder press one'},
  {sourceStart: 266, seconds: 4, centerX: 640, name: 'Shoulder press two'},
  {sourceStart: 320, seconds: 6, centerX: 640, name: 'Final set one'},
  {sourceStart: 372, seconds: 4, centerX: 640, name: 'Final set two'},
  {sourceStart: 388, seconds: 5, centerX: 640, name: 'Closing'},
];

export const fps = 30;
export const width = 1080;
export const height = 1920;
export const sourceWidth = 1280;
export const sourceHeight = 720;
export const totalFrames = clips.reduce((sum, clip) => sum + clip.seconds * fps, 0);
// The finished Upper Body long edit already contains clean exercise labels.
export const sourceHasExerciseLabels = true;
