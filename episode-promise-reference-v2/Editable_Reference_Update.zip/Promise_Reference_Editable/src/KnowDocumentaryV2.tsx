import React from 'react';
import {AbsoluteFill,Audio,Composition,Img,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Subtitle} from './KnowDocumentary';
import plan from './know-edit-v2.json';

type Cut = (typeof plan.cuts)[number];
type Visual = {start:number;duration:number;sourceStart:number};
const source = staticFile('media/know-source.mp4');
const dialogue = staticFile('media/know-dialogue-v2.wav');
const endingStill = staticFile('media/know-ending-still.jpg');
const music = staticFile('media/run-discover.mp3');
const frames = (s:number)=>Math.round(s*plan.fps);
const gradeFor = (cut:Cut)=>plan.grade[cut.look as keyof typeof plan.grade];

const EndingStill:React.FC<{grade:string}>=({grade})=>{
  const frame=useCurrentFrame();
  return <AbsoluteFill style={{overflow:'hidden',backgroundColor:'#11171c'}}>
    <Img src={endingStill} style={{width:'100%',height:'100%',objectFit:'cover',filter:grade,
      transform:`scale(${1.0+Math.min(frame/3600,.018)})`}}/>
  </AbsoluteFill>;
};

const PolishedShot:React.FC<{cut:Cut;index:number}>=({cut,index})=>{
  const duration=frames(cut.duration);
  const stillAfter='stillAfter' in cut?Number(cut.stillAfter):null;
  const cutVisuals='visuals' in cut?cut.visuals as Visual[]:null;
  const videoFrames=stillAfter===null?duration:frames(stillAfter);
  const grade=gradeFor(cut);
  return <AbsoluteFill style={{backgroundColor:'#12181d',overflow:'hidden'}}>
    {cutVisuals?cutVisuals.map((visual,i)=><Sequence key={i} from={frames(visual.start)} durationInFrames={frames(visual.duration)}>
      <OffthreadVideo src={source} muted trimBefore={frames(visual.sourceStart)} durationInFrames={frames(visual.duration)}
        style={{width:'100%',height:'100%',objectFit:'cover',filter:grade}}/>
    </Sequence>):<Sequence durationInFrames={videoFrames}>
      <OffthreadVideo src={source} muted trimBefore={frames(cut.videoStart)} durationInFrames={videoFrames}
        style={{width:'100%',height:'100%',objectFit:'cover',filter:grade,
          transform:`scale(${index%4===0?1.012:1})`}}/>
    </Sequence>}
    {stillAfter!==null&&<Sequence from={videoFrames} durationInFrames={duration-videoFrames}>
      <EndingStill grade={grade}/>
    </Sequence>}
    <Audio src={dialogue} trimBefore={frames(cut.audioStart)} volume={f=>interpolate(f,[0,2,Math.max(3,duration-3),duration],
      [0,cut.gain,cut.gain,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    {cut.captions.map((caption,i)=><Sequence key={i} from={frames(caption.start)}
      durationInFrames={Math.max(1,frames(caption.end-caption.start))}>
      <Subtitle text={caption.text} duration={frames(caption.end-caption.start)}/>
    </Sequence>)}
  </AbsoluteFill>;
};

const PolishedStory:React.FC<{cuts:Cut[]}>=({cuts})=>{
  const {width}=useVideoConfig();
  const duration=cuts.reduce((sum,cut)=>sum+frames(cut.duration),0);
  let at=0;
  return <AbsoluteFill style={{backgroundColor:'#12181d'}}>
    {cuts.map((cut,i)=>{const from=at;at+=frames(cut.duration);return <Sequence key={i} from={from}
      durationInFrames={frames(cut.duration)} name={`${i+1}. ${cut.name}`}>
      <PolishedShot cut={cut} index={i}/>
    </Sequence>})}
    <Audio src={music} volume={f=>{
      const sec=f/plan.fps;
      const level=sec>58&&sec<70?.025:.033;
      return level*interpolate(f,[0,24,Math.max(25,duration-75),duration-1],
        [0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
    }}/>
    <Sequence durationInFrames={frames(2)} name="Channel identity">
      <AbsoluteFill style={{padding:`${39*width/1280}px ${49*width/1280}px`,
        font:`700 ${20*width/1280}px Arial, Helvetica, sans-serif`,letterSpacing:3*width/1280,
        color:'#edf4f0',textShadow:'0 2px 9px #000',opacity:.88}}>
        1% BETTER WITH BIBEK
      </AbsoluteFill>
    </Sequence>
  </AbsoluteFill>;
};

export const KnowV2Final:React.FC=()=> <PolishedStory cuts={plan.cuts}/>;
const previewCuts=plan.cuts.slice(8);
export const KnowV2Preview:React.FC=()=> <PolishedStory cuts={previewCuts}/>;
export const KnowV2Compositions=()=> <>
  <Composition id="IKnowWhatToDoV2Final" component={KnowV2Final}
    durationInFrames={plan.cuts.reduce((s,c)=>s+frames(c.duration),0)} fps={plan.fps}
    width={plan.width} height={plan.height}/>
  <Composition id="IKnowWhatToDoV2Preview" component={KnowV2Preview}
    durationInFrames={previewCuts.reduce((s,c)=>s+frames(c.duration),0)} fps={plan.fps}
    width={640} height={360}/>
</>;
