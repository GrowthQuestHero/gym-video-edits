// Source timecodes are verified against the original 5:48 running recording.
// The opening previews a later running moment; the rest follows the session.
export type RunningShortCut={sourceStart:number;seconds:number;centerX:number;section:'hook'|'warmup'|'rear'|'pause'|'side'|'stop'|'ending';name:string};
export const runningShortFps=30;
export const runningShortCuts:RunningShortCut[]=[
  {sourceStart:200,seconds:3,centerX:610,section:'hook',name:'Running hook'},
  {sourceStart:24,seconds:3,centerX:670,section:'warmup',name:'Warm-up'},
  {sourceStart:70,seconds:3,centerX:670,section:'rear',name:'Starting the run'},
  {sourceStart:83,seconds:5,centerX:670,section:'rear',name:'Early run'},
  {sourceStart:98,seconds:4,centerX:670,section:'rear',name:'Run continues'},
  {sourceStart:108,seconds:5,centerX:670,section:'rear',name:'Continuing on treadmill'},
  {sourceStart:133,seconds:3,centerX:650,section:'pause',name:'Water pause'},
  {sourceStart:155,seconds:6,centerX:610,section:'side',name:'Return to running'},
  {sourceStart:180,seconds:6,centerX:610,section:'side',name:'Side-angle run'},
  {sourceStart:215,seconds:5,centerX:610,section:'side',name:'Later run'},
  {sourceStart:237,seconds:4,centerX:610,section:'side',name:'Final running stretch'},
  {sourceStart:250,seconds:6,centerX:650,section:'stop',name:'Treadmill segment ends'},
  {sourceStart:302,seconds:2,centerX:680,section:'stop',name:'After the run'},
  {sourceStart:335,seconds:3,centerX:620,section:'ending',name:'Closing image'},
];
export const runningShortFrames=runningShortCuts.reduce((sum,cut)=>sum+cut.seconds*runningShortFps,0);
if(runningShortFrames!==1740)throw new Error(`Running Short must be 1740 frames; got ${runningShortFrames}`);

export const runningShortCaptions=[
  {from:0,seconds:3,text:'AAJA KO CHALLENGE...'},
  {from:4,seconds:4,text:'START GARNA SAJILO CHA...'},
  {from:13,seconds:3,text:'TARA CONTINUE GARNA?'},
  {from:23,seconds:5,text:'MOTIVATION HAINA.\nCONSISTENCY.'},
  {from:37,seconds:4,text:'EK STEP AT A TIME.'},
  {from:49,seconds:4,text:'AAJA KO RUN YAHI SAKIYO.'},
  {from:55,seconds:3,text:'1% BETTER EVERY DAY.'},
];
