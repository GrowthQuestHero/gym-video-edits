import React from 'react';
import {AbsoluteFill,Audio,Composition,Img,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame} from 'remotion';
import longPlan from './know-edit-v2.json';
import shortPlan from './know-short-edit.json';
import allCaptions from './know-short-captions.json';

type Segment = (typeof shortPlan.segments)[number];
type Caption = (typeof allCaptions)[number];
const fps = shortPlan.fps;
const source = staticFile('media/know-source.mp4');
const dialogue = staticFile(`media/${shortPlan.dialogue}`);
const music = staticFile(`media/${shortPlan.music}`);
const finalStill = staticFile('media/know-ending-still.jpg');
const totalFrames = 1740;
const previewIndices = [0, 7, 10];
const originalStarts = shortPlan.segments.map((_, i) => shortPlan.segments.slice(0, i).reduce((n, s) => n + s.durationFrames, 0));

const PortraitCaption: React.FC<{text: string; duration: number}> = ({text, duration}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 5, Math.max(6, duration - 5), duration], [0, 1, 1, 0],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const size = text.length > 71 ? 43 : text.length > 48 ? 49 : 57;
  return <AbsoluteFill style={{justifyContent:'flex-end', alignItems:'center', padding:'0 64px 235px', pointerEvents:'none'}}>
    <div style={{whiteSpace:'pre-line', maxWidth:940, textAlign:'center', fontFamily:'Arial, Helvetica, sans-serif',
      fontWeight:800, fontSize:size, lineHeight:1.15, letterSpacing:-.5, color:'#faf8f2',
      textShadow:'0 3px 12px #000, 0 0 18px #000', background:'rgba(7,12,17,.68)',
      padding:'16px 25px', borderRadius:12, opacity}}>{text}</div>
  </AbsoluteFill>;
};

const ShortShot: React.FC<{segment:Segment}> = ({segment}) => {
  const frame = useCurrentFrame();
  const parent = longPlan.cuts[segment.cut];
  const grade = longPlan.grade[parent.look as keyof typeof longPlan.grade];
  const background = staticFile(`media/know-short-stills/${segment.still}`);
  const focalPosition = Math.max(0, Math.min(100, ((segment.focusX * 1280 - 300) / 680) * 100));
  const isPortrait = segment.framing === 'portrait';
  const audioStartFrame = Math.round(parent.audioStart * fps) + segment.offsetFrames;
  const videoStyle:React.CSSProperties={width:'100%', height:'100%', objectFit:isPortrait?'cover':'contain',
    objectPosition:`${focalPosition}% center`, filter:grade,
    transform:isPortrait?`scale(${1 + Math.min(frame/segment.durationFrames,1)*.012})`:undefined};
  return <AbsoluteFill style={{backgroundColor:'#111820', overflow:'hidden'}}>
    <Img src={background} style={{width:'100%', height:'100%', objectFit:'cover', filter:`${grade} blur(30px) brightness(.31)`, transform:'scale(1.16)'}}/>
    <div style={{position:'absolute', left:0, top:isPortrait?138:323, width:'100%', height:isPortrait?1440:1110,
      overflow:'hidden', boxShadow:'0 18px 62px rgba(0,0,0,.38)', background:'#111820'}}>
      {('visualSlices' in segment && segment.visualSlices) ? segment.visualSlices.map((slice,i)=><Sequence key={i}
        from={slice.startFrames} durationInFrames={slice.durationFrames}>
        <OffthreadVideo src={source} muted trimBefore={Math.round(slice.sourceStart*fps)}
          durationInFrames={slice.durationFrames} style={{...videoStyle,
            objectPosition:`${Math.max(0,Math.min(100,((slice.focusX*1280-300)/680)*100))}% center`}}/>
      </Sequence>) : <OffthreadVideo src={source} muted trimBefore={Math.round(segment.visualStart*fps)}
        durationInFrames={segment.durationFrames} style={videoStyle}/>}
    </div>
    <Audio src={dialogue} trimBefore={audioStartFrame} volume={f=>interpolate(f,
      [0,2,Math.max(3,segment.durationFrames-3),segment.durationFrames],
      [0,parent.gain,parent.gain,0], {extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
  </AbsoluteFill>;
};

const ClosingHold: React.FC = () => {
  const frame=useCurrentFrame();
  const opacity=interpolate(frame,[0,9,58,77],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{background:'#111820'}}>
    <Img src={finalStill} style={{width:'100%', height:'100%', objectFit:'cover', objectPosition:'52% center',
      filter:`${longPlan.grade.final} brightness(.55)`}}/>
    <AbsoluteFill style={{background:'linear-gradient(0deg, rgba(5,9,14,.78), rgba(5,9,14,.18))'}}/>
    <AbsoluteFill style={{justifyContent:'flex-end', alignItems:'center', padding:'0 55px 385px',opacity}}>
      <div style={{font:'800 77px Arial, Helvetica, sans-serif', letterSpacing:1, color:'#f8f5ec',
        textAlign:'center', lineHeight:1.05, textShadow:'0 3px 16px #000'}}>1% BETTER<br/>EVERY DAY.</div>
    </AbsoluteFill>
  </AbsoluteFill>;
};

function arrange(indices:number[]) {
  let current=0;
  const segments=indices.map(index=>{
    const seg=shortPlan.segments[index];
    const item={segment:seg, from:current, originalFrom:originalStarts[index]};
    current+=seg.durationFrames;
    return item;
  });
  const captions:Caption[]=segments.flatMap(item=>allCaptions.filter(c=>
    c.endFrame>item.originalFrom && c.startFrame<item.originalFrom+item.segment.durationFrames).map(c=>({
      startFrame:item.from+Math.max(0,c.startFrame-item.originalFrom),
      endFrame:item.from+Math.min(item.segment.durationFrames,c.endFrame-item.originalFrom),
      text:c.text
    })));
  return {segments,captions,speechFrames:current};
}

const ShortStory: React.FC<{preview?:boolean}> = ({preview=false}) => {
  const indices=preview?previewIndices:shortPlan.segments.map((_,i)=>i);
  const {segments,captions,speechFrames}=arrange(indices);
  const hold=preview?Math.min(45,shortPlan.closingHoldFrames):shortPlan.closingHoldFrames;
  const duration=speechFrames+hold;
  return <AbsoluteFill style={{background:'#111820'}}>
    {segments.map((item,i)=><Sequence key={i} from={item.from} durationInFrames={item.segment.durationFrames}
      name={`${i+1}. ${longPlan.cuts[item.segment.cut].name}`}>
      <ShortShot segment={item.segment}/>
    </Sequence>)}
    <Sequence from={speechFrames} durationInFrames={hold} name="Closing identity"><ClosingHold/></Sequence>
    <Audio src={music} volume={f=>{
      const finalSection = f > speechFrames-270;
      const bed = finalSection ? .019 : .027;
      return bed*interpolate(f,[0,16,Math.max(17,duration-46),duration-1],[0,1,1,0],
        {extrapolateLeft:'clamp',extrapolateRight:'clamp'});
    }}/>
    {captions.map((c,i)=><Sequence key={i} from={c.startFrame} durationInFrames={c.endFrame-c.startFrame}
      name={`Caption ${i+1}`}><PortraitCaption text={c.text} duration={c.endFrame-c.startFrame}/></Sequence>)}
  </AbsoluteFill>;
};

export const KnowShortFinal:React.FC=()=> <ShortStory/>;
export const KnowShortPreview:React.FC=()=> <ShortStory preview/>;
const previewFrames=previewIndices.reduce((sum,i)=>sum+shortPlan.segments[i].durationFrames,0)+45;
export const KnowShortCompositions=()=> <>
  <Composition id="IKnowWhatToDoShort58s" component={KnowShortFinal} durationInFrames={totalFrames}
    width={shortPlan.width} height={shortPlan.height} fps={fps}/>
  <Composition id="IKnowWhatToDoShortPreview" component={KnowShortPreview} durationInFrames={previewFrames}
    width={shortPlan.width} height={shortPlan.height} fps={fps}/>
</>;
