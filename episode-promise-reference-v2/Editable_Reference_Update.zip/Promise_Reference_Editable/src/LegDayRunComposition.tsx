import React from 'react';
import {AbsoluteFill,Audio,Composition,Img,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame} from 'remotion';
import plan from './leg-run-edit.json';

type Cut=(typeof plan.cuts)[number];
type Cue={fromFrame:number;durationFrames:number;text:string};
const fps=plan.fps;
const source=staticFile(plan.source);
const deepUrban=staticFile('media/run-deep-urban.mp3');
const newLife=staticFile('media/run-new-life.mp3');
const sweep=staticFile('media/run-small-sweep.wav');
const mix=plan.musicMixMultiplier;
const ending=staticFile('media/leg-run-ending.jpg');
const fullSpeechFrames=plan.cuts.reduce((s,c)=>s+c.durationFrames,0);
const fullFrames=fullSpeechFrames+plan.closingHoldFrames;

const ClaimMask:React.FC<{kind:string}>=({kind})=>{
  if(kind==='press45')return <div style={{position:'absolute',left:495,top:510,width:320,height:112,
    background:'rgba(15,21,29,.96)',borderLeft:'5px solid #b7c9ca',boxSizing:'border-box',
    display:'flex',alignItems:'center',paddingLeft:25,color:'#f4f7f3',
    font:'800 33px Arial, Helvetica, sans-serif',letterSpacing:1}}>LEG PRESS</div>;
  if(kind==='distance')return <div style={{position:'absolute',left:415,top:317,width:372,height:86,
    background:'rgba(14,20,28,.97)',borderLeft:'5px solid #b7c9ca',boxSizing:'border-box',
    display:'flex',alignItems:'center',paddingLeft:23,color:'#f4f7f3',
    font:'800 31px Arial, Helvetica, sans-serif',letterSpacing:1}}>TREADMILL</div>;
  return null;
};

const Shot:React.FC<{cut:Cut;index:number}>=({cut,index})=>{
  const frame=useCurrentFrame();
  const look=plan.looks[cut.section as keyof typeof plan.looks];
  const slightPush=index===0?`scale(${1+Math.min(frame/cut.durationFrames,1)*.015})`:undefined;
  return <AbsoluteFill style={{background:'#111820',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={Math.round(cut.sourceStart*fps)}
      durationInFrames={cut.durationFrames} style={{width:'100%',height:'100%',objectFit:'cover',filter:look,
        transform:slightPush}}/>
    <ClaimMask kind={cut.mask}/>
  </AbsoluteFill>;
};

const Caption:React.FC<{text:string;frames:number}>=({text,frames})=>{
  const f=useCurrentFrame();
  const opacity=interpolate(f,[0,8,Math.max(9,frames-9),frames-1],[0,1,1,0],
    {extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const rise=interpolate(f,[0,11],[9,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{pointerEvents:'none',padding:'48px 58px'}}>
    <div style={{width:82,height:5,background:'#b7c9ca',marginBottom:16,opacity}}/>
    <div style={{display:'inline-block',maxWidth:750,padding:'9px 15px 10px',background:'rgba(8,13,19,.58)',
      font:'800 42px Arial, Helvetica, sans-serif',lineHeight:1.1,letterSpacing:1.1,color:'#f6f6f2',
      textShadow:'0 2px 10px #000',opacity,transform:`translateY(${rise}px)`}}>{text}</div>
  </AbsoluteFill>;
};

const Closing:React.FC<{frames:number}>=({frames})=>{
  const f=useCurrentFrame();
  const opacity=interpolate(f,[0,12,Math.max(13,frames-16),frames-1],[0,1,1,0],
    {extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{background:'#111820'}}>
    <Img src={ending} style={{width:'100%',height:'100%',objectFit:'cover',filter:plan.looks.run}}/>
    <AbsoluteFill style={{background:'linear-gradient(90deg,rgba(5,10,16,.7),transparent 72%)'}}/>
    <AbsoluteFill style={{justifyContent:'flex-end',padding:'0 60px 65px',opacity}}>
      <div style={{font:'800 56px Arial, Helvetica, sans-serif',lineHeight:1.06,color:'#f6f5ef',
        letterSpacing:.5,textShadow:'0 3px 14px #000'}}>1% BETTER EVERY DAY.</div>
    </AbsoluteFill>
  </AbsoluteFill>;
};

const Soundtrack:React.FC<{duration:number;runStart:number}>=({duration,runStart})=>{
  const newStart=Math.max(0,duration-20*fps);
  return <>
    <Audio src={deepUrban} volume={f=>mix*.125*interpolate(f,[0,24,Math.max(25,newStart),Math.max(newStart+1,duration-85)],
      [0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence from={newStart} durationInFrames={duration-newStart}>
      <Audio src={newLife} volume={f=>mix*.11*interpolate(f,[0,55,Math.max(56,duration-newStart-70),duration-newStart-1],
        [0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    </Sequence>
    <Sequence durationInFrames={28}><Audio src={sweep} volume={mix*.022}/></Sequence>
    <Sequence from={runStart} durationInFrames={28}><Audio src={sweep} volume={mix*.022}/></Sequence>
  </>;
};

const Story:React.FC<{cuts:Cut[];captions:Cue[];hold:number}>=({cuts,captions,hold})=>{
  const content=cuts.reduce((s,c)=>s+c.durationFrames,0);
  const duration=content+hold;
  let at=0;
  const runStart=cuts.slice(0,cuts.findIndex(c=>c.section==='run')).reduce((s,c)=>s+c.durationFrames,0);
  return <AbsoluteFill style={{background:'#111820'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.durationFrames;return <Sequence key={i} from={from}
      durationInFrames={cut.durationFrames} name={`${i+1}. ${cut.name}`}>
      <Shot cut={cut} index={i}/>
    </Sequence>})}
    <Sequence from={content} durationInFrames={hold} name="Closing"><Closing frames={hold}/></Sequence>
    <Soundtrack duration={duration} runStart={runStart}/>
    {captions.map((c,i)=><Sequence key={i} from={c.fromFrame} durationInFrames={c.durationFrames}
      name={`Caption: ${c.text}`}><Caption text={c.text} frames={c.durationFrames}/></Sequence>)}
  </AbsoluteFill>;
};

const previewCuts:Cut[]=[
  {...plan.cuts[0],durationFrames:90},
  {...plan.cuts[2],durationFrames:150},
  {...plan.cuts[5],durationFrames:120},
  {...plan.cuts[7],durationFrames:150},
  {...plan.cuts[14],durationFrames:180},
];
const previewCaptions:Cue[]=[
  {fromFrame:0,durationFrames:80,text:'AAJA KO WORKOUT...'},
  {fromFrame:90,durationFrames:85,text:'LEG PRESS'},
  {fromFrame:240,durationFrames:80,text:'CALF RAISES'},
  {fromFrame:360,durationFrames:80,text:'SQUATS'},
  {fromFrame:510,durationFrames:90,text:'LAST MA, TREADMILL.'},
];

export const LegDayRunFinal:React.FC=()=> <Story cuts={plan.cuts} captions={plan.captions} hold={plan.closingHoldFrames}/>;
export const LegDayRunPreview:React.FC=()=> <Story cuts={previewCuts} captions={previewCaptions} hold={90}/>;
export const LegDayRunCompositions=()=> <>
  <Composition id="LegDayRunCinematicFinal" component={LegDayRunFinal} durationInFrames={fullFrames}
    fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="LegDayRunCinematicPreview" component={LegDayRunPreview}
    durationInFrames={previewCuts.reduce((s,c)=>s+c.durationFrames,0)+90}
    fps={fps} width={plan.width} height={plan.height}/>
</>;
