import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import plan from './upper-ice-edit.json';

type Cut = (typeof plan.cuts)[number];
const fps = plan.fps;
const source = staticFile(plan.source);
const total = plan.cuts.reduce((sum, cut) => sum + cut.seconds * fps, 0);

const Caption: React.FC<{text:string; frames:number}> = ({text, frames}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f,[0,9,Math.max(10,frames-10),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',alignItems:'flex-start',padding:'0 50px 48px',pointerEvents:'none'}}>
    <div style={{background:'rgba(6,12,17,.66)',borderLeft:'4px solid #c5d5cf',padding:'10px 16px',font:'800 35px Arial, Helvetica, sans-serif',letterSpacing:1,color:'#f7f7f1',textShadow:'0 2px 8px #000',opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot:React.FC<{cut:Cut}>=({cut})=>{
  const frames=cut.seconds*fps;
  const filter=plan.looks[cut.section as keyof typeof plan.looks];
  return <AbsoluteFill style={{background:'#101720',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={cut.sourceStart*fps} durationInFrames={frames} style={{width:'100%',height:'100%',objectFit:'cover',filter}}/>
    {cut.caption ? <Sequence from={12} durationInFrames={Math.min(100,frames-12)}><Caption text={cut.caption} frames={Math.min(100,frames-12)}/></Sequence>:null}
  </AbsoluteFill>;
};

const Story:React.FC<{cuts:Cut[]}>=({cuts})=>{
  const duration=cuts.reduce((sum,c)=>sum+c.seconds*fps,0);
  const bathStart=139*fps;
  let at=0;
  return <AbsoluteFill style={{background:'#101720'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.seconds*fps;return <Sequence key={i} name={`${i+1}. ${cut.name}`} from={from} durationInFrames={cut.seconds*fps}><Shot cut={cut}/></Sequence>;})}
    <Audio src={staticFile('media/run-deep-urban.mp3')} trimBefore={15*fps} volume={f=>.15*interpolate(f,[0,30,Math.max(31,bathStart-30),bathStart+75],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence from={bathStart} durationInFrames={duration-bathStart}><Audio src={staticFile('media/run-new-life.mp3')} trimBefore={28*fps} volume={f=>.13*interpolate(f,[0,70,Math.max(71,duration-bathStart-4*fps),duration-bathStart-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/></Sequence>
    <Sequence durationInFrames={20}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.02}/></Sequence>
  </AbsoluteFill>;
};

const previewCuts:Cut[]=[plan.cuts[0],plan.cuts[3],plan.cuts[7],plan.cuts[10],plan.cuts[14],plan.cuts[15]].map(c=>({...c,seconds:3}));
export const UpperIceCompositions=()=> <>
  <Composition id="UpperIceFinal" component={()=><Story cuts={plan.cuts}/>} durationInFrames={total} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="UpperIcePreview" component={()=><Story cuts={previewCuts}/>} durationInFrames={previewCuts.reduce((s,c)=>s+c.seconds*fps,0)} fps={fps} width={plan.width} height={plan.height}/>
</>;
