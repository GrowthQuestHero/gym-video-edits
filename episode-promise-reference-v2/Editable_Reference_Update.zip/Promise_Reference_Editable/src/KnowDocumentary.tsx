import React from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import plan from './know-edit.json';

type Cut = (typeof plan.cuts)[number];
const fps = plan.fps;
const source = staticFile('media/know-source.mp4');
const dialogue = staticFile('media/know-dialogue.wav');
const music = staticFile('media/run-discover.mp3');
const frames = (seconds:number) => Math.round(seconds * fps);
const looks:Record<string,string> = {
  neutral:'brightness(1.035) contrast(1.025) saturate(.97)',
  daylight:'brightness(1.025) contrast(1.025) saturate(.97)',
  interior:'brightness(1.065) contrast(1.025) saturate(.96)',
  gym:'brightness(1.095) contrast(1.02) saturate(.96)',
};

export const Subtitle:React.FC<{text:string;duration:number}>=({text,duration})=>{
  const frame=useCurrentFrame();
  const {width}=useVideoConfig();
  const k=width/1280;
  const opacity=interpolate(frame,[0,5,Math.max(6,duration-6),duration],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',alignItems:'center',padding:`0 ${70*k}px ${47*k}px`,pointerEvents:'none'}}>
    <div style={{whiteSpace:'pre-line',maxWidth:1050*k,textAlign:'center',fontFamily:'Arial, Helvetica, sans-serif',fontSize:39*k,fontWeight:700,lineHeight:1.14,
      color:'#f8f8f4',textShadow:`0 ${2*k}px ${7*k}px #000, 0 0 ${17*k}px #000`,background:'rgba(4,8,10,.52)',padding:`${10*k}px ${20*k}px`,borderRadius:4*k,opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Shot:React.FC<{cut:Cut;index:number}>=({cut,index})=>{
  const duration=frames(cut.duration);
  const zoom=index%4===0?1.016:1;
  return <AbsoluteFill style={{backgroundColor:'#101416',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={frames(cut.videoStart)} durationInFrames={duration}
      style={{width:'100%',height:'100%',objectFit:'cover',filter:looks[cut.look]||looks.neutral,transform:`scale(${zoom})`}}/>
    <Audio src={dialogue} trimBefore={frames(cut.audioStart)} volume={f=>interpolate(f,[0,2,Math.max(3,duration-3),duration],[0,cut.gain,cut.gain,0],
      {extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    {cut.captions.map((caption,i)=><Sequence key={i} from={frames(caption.start)} durationInFrames={Math.max(1,frames(caption.end-caption.start))} name={`Subtitle: ${caption.text}`}>
      <Subtitle text={caption.text} duration={frames(caption.end-caption.start)}/>
    </Sequence>)}
  </AbsoluteFill>;
};

const Story:React.FC<{cuts:Cut[]}>=({cuts})=>{
  const {width}=useVideoConfig();
  const k=width/1280;
  const duration=cuts.reduce((sum,cut)=>sum+frames(cut.duration),0);
  let at=0;
  return <AbsoluteFill style={{backgroundColor:'#101416'}}>
    {cuts.map((cut,i)=>{const from=at;at+=frames(cut.duration);return <Sequence key={i} from={from} durationInFrames={frames(cut.duration)} name={`${i+1}. ${cut.name}`}>
      <Shot cut={cut} index={i}/>
    </Sequence>})}
    <Audio src={music} volume={f=>{
      const sec=f/fps;
      const level=sec>64&&sec<78?.067:sec>80&&sec<95?.025:.037;
      return level*interpolate(f,[0,24,Math.max(25,duration-90),duration-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
    }}/>
    <Sequence durationInFrames={frames(2)} name="Channel identity">
      <AbsoluteFill style={{padding:`${39*k}px ${49*k}px`,font:`700 ${20*k}px Arial, Helvetica, sans-serif`,letterSpacing:3*k,color:'#edf4f0',textShadow:'0 2px 9px #000',opacity:.88}}>
        1% BETTER WITH BIBEK
      </AbsoluteFill>
    </Sequence>
  </AbsoluteFill>;
};

const previewIndices=[0,2,8,11,14];
const previewCuts=previewIndices.map(i=>plan.cuts[i]);
export const KnowFinal:React.FC=()=> <Story cuts={plan.cuts}/>;
export const KnowPreview:React.FC=()=> <Story cuts={previewCuts}/>;
export const KnowCompositions=()=> <>
  <Composition id="IKnowWhatToDoFinal" component={KnowFinal} durationInFrames={plan.cuts.reduce((s,c)=>s+frames(c.duration),0)} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="IKnowWhatToDoPreview" component={KnowPreview} durationInFrames={previewCuts.reduce((s,c)=>s+frames(c.duration),0)} fps={fps} width={640} height={360}/>
</>;
