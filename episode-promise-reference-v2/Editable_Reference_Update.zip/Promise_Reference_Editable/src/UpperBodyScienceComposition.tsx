import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import plan from './upper-body-science-edit.json';

type Cut = (typeof plan.cuts)[number];
const source = staticFile(plan.source);
const deepUrban = staticFile('media/run-deep-urban.mp3');
const newLife = staticFile('media/run-new-life.mp3');
const sweep = staticFile('media/run-small-sweep.wav');
const totalFrames = plan.cuts.reduce((sum, cut) => sum + cut.durationFrames, 0);

const Caption: React.FC<{text: string; duration: number}> = ({text, duration}) => {
  const frame = useCurrentFrame();
  const fadeOut = Math.max(12, duration - 12);
  const opacity = interpolate(frame, [0, 9, fadeOut, duration - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rise = interpolate(frame, [0, 12], [9, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'flex-start', padding: '0 54px 54px', pointerEvents: 'none'}}>
    <div style={{width: 68, height: 4, background: '#bdc9c5', marginBottom: 13, opacity}} />
    <div style={{maxWidth: 800, padding: '9px 14px 10px', background: 'rgba(7,12,18,0.54)', color: '#f5f4ef', font: '800 34px Arial, Helvetica, sans-serif', lineHeight: 1.13, letterSpacing: 1, textShadow: '0 2px 8px rgba(0,0,0,.7)', opacity, transform: `translateY(${rise}px)`}}>{text}</div>
  </AbsoluteFill>;
};

const Shot: React.FC<{cut: Cut; index: number}> = ({cut, index}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const filter = plan.looks[cut.section as keyof typeof plan.looks];
  const scale = index === 0 ? 1 + 0.014 * Math.min(frame / cut.durationFrames, 1) : 1;
  return <AbsoluteFill style={{background: '#111820', overflow: 'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={Math.round(cut.sourceStart * fps)} durationInFrames={cut.durationFrames}
      style={{width: '100%', height: '100%', objectFit: 'cover', filter, transform: `scale(${scale})`}} />
    {cut.caption ? <Sequence from={12} durationInFrames={Math.min(110, cut.durationFrames - 14)}>
      <Caption text={cut.caption} duration={Math.min(110, cut.durationFrames - 14)} />
    </Sequence> : null}
  </AbsoluteFill>;
};

const Soundtrack: React.FC<{duration: number}> = ({duration}) => {
  const fadeToClosing = Math.max(0, duration - 24 * plan.fps);
  return <>
    <Audio src={deepUrban} volume={(frame) => 0.135 * interpolate(frame, [0, 24, fadeToClosing, fadeToClosing + 65], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    <Sequence from={fadeToClosing} durationInFrames={duration - fadeToClosing}>
      <Audio src={newLife} volume={(frame) => 0.12 * interpolate(frame, [0, 65, Math.max(66, duration - fadeToClosing - 55), duration - fadeToClosing - 1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    </Sequence>
    <Sequence durationInFrames={24}><Audio src={sweep} volume={0.018} /></Sequence>
  </>;
};

const Story: React.FC<{cuts: Cut[]}> = ({cuts}) => {
  const duration = cuts.reduce((sum, cut) => sum + cut.durationFrames, 0);
  let at = 0;
  return <AbsoluteFill style={{background: '#111820'}}>
    {cuts.map((cut, index) => {
      const from = at; at += cut.durationFrames;
      return <Sequence key={index} name={`${index + 1}. ${cut.name}`} from={from} durationInFrames={cut.durationFrames}>
        <Shot cut={cut} index={index} />
      </Sequence>;
    })}
    <Soundtrack duration={duration} />
  </AbsoluteFill>;
};

const previewCuts = [plan.cuts[0], plan.cuts[2], plan.cuts[5], plan.cuts[7], plan.cuts[9], plan.cuts[14], plan.cuts[19]].map(cut => ({...cut, durationFrames: Math.min(cut.durationFrames, 120)}));
export const UpperBodyScienceFinal: React.FC = () => <Story cuts={plan.cuts} />;
export const UpperBodySciencePreview: React.FC = () => <Story cuts={previewCuts} />;
export const UpperBodyScienceCompositions = () => <>
  <Composition id="UpperBodyScienceCinematicFinal" component={UpperBodyScienceFinal} durationInFrames={totalFrames} fps={plan.fps} width={plan.width} height={plan.height} />
  <Composition id="UpperBodyScienceCinematicPreview" component={UpperBodySciencePreview} durationInFrames={previewCuts.reduce((sum, cut) => sum + cut.durationFrames, 0)} fps={plan.fps} width={plan.width} height={plan.height} />
</>;
