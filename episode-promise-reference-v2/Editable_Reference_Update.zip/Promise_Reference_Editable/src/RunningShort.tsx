import React from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {runningShortCaptions,runningShortCuts,runningShortFps,runningShortFrames,type RunningShortCut} from './running-short-config';

const source=staticFile('media/running-source.mp4');
const filters:Record<RunningShortCut['section'],string>={
  hook:'brightness(1.10) contrast(1.03) saturate(.93)',
  warmup:'brightness(1.07) contrast(1.03) saturate(.94)',
  rear:'brightness(1.08) contrast(1.03) saturate(.94)',
  pause:'brightness(1.07) contrast(1.03) saturate(.94)',
  side:'brightness(1.10) contrast(1.02) saturate(.94)',
  stop:'brightness(1.10) contrast(1.02) saturate(.94)',
  ending:'brightness(1.08) contrast(1.02) saturate(.94)',
};

const VerticalShot:React.FC<RunningShortCut>=({sourceStart,seconds,centerX,section})=>{
  const {width,height}=useVideoConfig();
  const frame=useCurrentFrame();
  const scale=height/720;
  const push=section==='hook'?interpolate(frame,[0,seconds*runningShortFps],[1,1.025],{extrapolateRight:'clamp'}):1;
  return <AbsoluteFill style={{background:'#090e11',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={sourceStart*runningShortFps} durationInFrames={seconds*runningShortFps}
      style={{position:'absolute',top:(height-height*push)/2,left:width/2-centerX*scale*push,
        width:1280*scale*push,height:height*push,filter:filters[section]}}/>
  </AbsoluteFill>;
};

export const Message:React.FC<{text:string;frames:number}>=({text,frames})=>{
  const frame=useCurrentFrame();
  const {width}=useVideoConfig();
  const k=width/1080;
  const opacity=interpolate(frame,[0,9,Math.max(10,frames-12),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const rise=interpolate(frame,[0,14],[20,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',padding:`0 ${85*k}px ${290*k}px`,pointerEvents:'none',
    background:'linear-gradient(to top,rgba(3,8,10,.53),transparent 44%)'}}>
    <div style={{width:95*k,height:7*k,marginBottom:24*k,background:'#a8d0c8',opacity}}/>
    <div style={{maxWidth:910*k,color:'#f5f5f0',fontFamily:'Arial, Helvetica, sans-serif',fontSize:68*k,
      fontWeight:800,lineHeight:1.08,letterSpacing:-1.2*k,whiteSpace:'pre-line',textShadow:'0 3px 16px #000',
      opacity,transform:`translateY(${rise*k}px)`}}>{text}</div>
  </AbsoluteFill>;
};

const Bed:React.FC<{seconds:number;startAt?:number}>=({seconds,startAt=0})=><>
  <Audio src={staticFile('media/driving-ambition.mp3')} trimBefore={16*runningShortFps}
    volume={f=>interpolate(f,[0,12,Math.max(13,Math.min(47,seconds-11)*runningShortFps),Math.min(50,seconds)*runningShortFps],
      [.11,.16,.16,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
  {seconds>50&&<Sequence from={47*runningShortFps} durationInFrames={(seconds-47)*runningShortFps}>
    <Audio src={staticFile('media/run-new-life.mp3')} trimBefore={30*runningShortFps}
      volume={f=>interpolate(f,[0,50,Math.max(51,(seconds-51)*runningShortFps),(seconds-47)*runningShortFps-1],
        [0,.13,.13,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
  </Sequence>}
  <Sequence from={startAt*runningShortFps} durationInFrames={32}>
    <Audio src={staticFile('media/run-small-sweep.wav')} volume={.035}/>
  </Sequence>
</>;

export const RunningShort:React.FC=()=>{
  let cursor=0;
  return <AbsoluteFill style={{background:'#090e11'}}>
    {runningShortCuts.map((cut,i)=>{const from=cursor;cursor+=cut.seconds*runningShortFps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*runningShortFps} name={`${i+1}: ${cut.name}`}><VerticalShot {...cut}/></Sequence>})}
    <Bed seconds={58}/>
    {runningShortCaptions.map((caption,i)=><Sequence key={i} from={caption.from*runningShortFps} durationInFrames={caption.seconds*runningShortFps} name={caption.text}>
      <Message text={caption.text} frames={caption.seconds*runningShortFps}/>
    </Sequence>)}
  </AbsoluteFill>;
};

const previewCuts=[runningShortCuts[0],runningShortCuts[1],runningShortCuts[3],runningShortCuts[7],runningShortCuts[11],runningShortCuts[13]];
export const RunningShortPreview:React.FC=()=>{
  let cursor=0;
  return <AbsoluteFill style={{background:'#090e11'}}>
    {previewCuts.map((cut,i)=>{const short={...cut,seconds:i===3?4:3};const from=cursor;cursor+=short.seconds*runningShortFps;return <Sequence key={i} from={from} durationInFrames={short.seconds*runningShortFps}><VerticalShot {...short}/></Sequence>})}
    <Bed seconds={19}/>
    {[{from:0,text:'AAJA KO CHALLENGE...'},{from:3,text:'START GARNA SAJILO CHA...'},{from:9,text:'MOTIVATION HAINA.\nCONSISTENCY.'},{from:16,text:'1% BETTER EVERY DAY.'}]
      .map((c,i)=><Sequence key={i} from={c.from*runningShortFps} durationInFrames={3*runningShortFps}>
        <Message text={c.text} frames={3*runningShortFps}/>
      </Sequence>)}
  </AbsoluteFill>;
};

export const RunningShortCompositions=()=> <>
  <Composition id="RunningShort58s" component={RunningShort} durationInFrames={runningShortFrames} fps={runningShortFps} width={1080} height={1920}/>
  <Composition id="RunningShortPreview" component={RunningShortPreview} durationInFrames={19*runningShortFps} fps={runningShortFps} width={360} height={640}/>
</>;
