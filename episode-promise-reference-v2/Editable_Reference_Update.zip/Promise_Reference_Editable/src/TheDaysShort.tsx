import React from 'react';
import {AbsoluteFill, Audio, Composition, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import plan from './the-days-short.json';

type Cut = (typeof plan.cuts)[number];
const fps = plan.fps;
const source = staticFile(plan.source);
const duration = plan.cuts.reduce((n, c) => n + c.seconds * fps, 0);

const Shot: React.FC<{cut: Cut}> = ({cut}) => {
  const {width, height} = useVideoConfig();
  const k = width / 1080;
  const w = 1500 * k;
  const h = 843.75 * k;
  const still = staticFile(`media/the-days-short-bg-${cut.section}.jpg`);
  return <AbsoluteFill style={{overflow: 'hidden', background: '#10161d'}}>
    <Img src={still} style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(56px) brightness(.28) saturate(.75)', transform: 'scale(1.2)'}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg,rgba(4,9,14,.57),transparent 35%,transparent 68%,rgba(4,9,14,.66))'}} />
    <div style={{position: 'absolute', left: (width-w)/2, top: (height-h)/2, width: w, height: h, overflow: 'hidden', boxShadow: '0 16px 75px rgba(0,0,0,.65)'}}>
      <OffthreadVideo src={source} muted trimBefore={cut.fromSecond * fps} durationInFrames={cut.seconds * fps} style={{width: w, height: h, objectFit: 'contain'}} />
    </div>
    <div style={{position:'absolute',top:205*k,left:64*k,right:64*k,color:'#e4ece8',font:`700 ${33*k}px Arial, Helvetica, sans-serif`,letterSpacing:2.3*k}}>1% BETTER WITH BIBEK</div>
    {cut.caption ? <Caption text={cut.caption} durationFrames={cut.seconds*fps} /> : null}
  </AbsoluteFill>;
};

const Caption: React.FC<{text: string; durationFrames: number}> = ({text, durationFrames}) => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const k = width / 1080;
  const opacity = interpolate(frame,[0,8,Math.max(9,durationFrames-10),durationFrames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{justifyContent:'flex-end',padding:`0 ${64*k}px ${340*k}px`,pointerEvents:'none'}}>
    <div style={{width:75*k,height:5*k,background:'#bdd0c9',marginBottom:20*k,opacity}} />
    <div style={{color:'#f7f7f2',font:`800 ${text.length>21?59*k:69*k}px Arial, Helvetica, sans-serif`,lineHeight:1.06,letterSpacing:.4*k,textShadow:'0 3px 18px #000',maxWidth:930*k,opacity}}>{text}</div>
  </AbsoluteFill>;
};

const Story: React.FC<{cuts: Cut[]}> = ({cuts}) => {
  let at = 0;
  const frames = cuts.reduce((n,c)=>n+c.seconds*fps,0);
  return <AbsoluteFill style={{background:'#10161d'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.seconds*fps;return <Sequence key={i} name={`${i+1}. ${cut.name}`} from={from} durationInFrames={cut.seconds*fps}><Shot cut={cut}/></Sequence>;})}
    <Audio src={staticFile('media/run-deep-urban.mp3')} trimBefore={20*fps} volume={f=>.17*interpolate(f,[0,15,Math.max(16,frames-60),frames-1],[.5,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence durationInFrames={20}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.022}/></Sequence>
  </AbsoluteFill>;
};

const previewCuts: Cut[] = [plan.cuts[0],plan.cuts[2],plan.cuts[4],plan.cuts[6],plan.cuts[7],plan.cuts[9]].map(c=>({...c,seconds:2}));
export const TheDaysShortCompositions = () => <>
  <Composition id="TheDaysNobodySeesShort58s" component={()=><Story cuts={plan.cuts}/>} durationInFrames={duration} fps={fps} width={plan.width} height={plan.height}/>
  <Composition id="TheDaysNobodySeesShortPreview" component={()=><Story cuts={previewCuts}/>} durationInFrames={previewCuts.reduce((n,c)=>n+c.seconds*fps,0)} fps={fps} width={360} height={640}/>
</>;
