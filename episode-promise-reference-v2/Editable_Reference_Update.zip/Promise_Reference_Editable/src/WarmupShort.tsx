import React from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,interpolate,staticFile,useVideoConfig} from 'remotion';
import {Message} from './RunningShort';
import {warmupShortCaptions,warmupShortCuts,warmupShortFps,warmupShortFrames,type WarmupShortCut} from './warmup-short-config';

const source=staticFile('media/warmup-source.mp4');
// Same natural correction as the completed warm-up long edit.
const color:Record<WarmupShortCut['section'],string>={
  hook:'brightness(1.02) contrast(1.035) saturate(.87)',
  arms:'brightness(1.055) contrast(1.025) saturate(.89)',
  triceps:'brightness(1.05) contrast(1.025) saturate(.89)',
  wrists:'brightness(1.055) contrast(1.025) saturate(.89)',
  lunge:'brightness(1.02) contrast(1.025) saturate(.86)',
  floor:'brightness(1.01) contrast(1.025) saturate(.86)',
  hamstring:'brightness(1.01) contrast(1.025) saturate(.86)',
  back:'brightness(1.015) contrast(1.025) saturate(.86)',
  cardio:'brightness(1.04) contrast(1.025) saturate(.89)',
  ending:'brightness(1.04) contrast(1.025) saturate(.89)',
};

const VerticalShot:React.FC<WarmupShortCut>=({sourceStart,seconds,centerX,fill,section})=>{
  const {width,height}=useVideoConfig();
  const scale=(height/720)*fill;
  const videoHeight=720*scale;
  return <AbsoluteFill style={{background:'linear-gradient(145deg,#172124,#090d0f)',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={sourceStart*warmupShortFps} durationInFrames={seconds*warmupShortFps}
      style={{position:'absolute',top:(height-videoHeight)/2,left:width/2-centerX*scale,
        width:1280*scale,height:videoHeight,filter:color[section]}}/>
  </AbsoluteFill>;
};

const Soundtrack:React.FC<{seconds:number}>=({seconds})=><>
  <Audio src={staticFile('media/run-discover.mp3')} trimBefore={10*warmupShortFps}
    volume={f=>seconds<48
      ?interpolate(f,[0,14,(seconds-4)*warmupShortFps,seconds*warmupShortFps-1],
        [.09,.14,.14,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})
      :interpolate(f,[0,14,24*warmupShortFps,48*warmupShortFps,(seconds-4)*warmupShortFps,seconds*warmupShortFps-1],
        [.09,.14,.14,.17,.17,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
  <Sequence durationInFrames={32}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.025}/></Sequence>
  {seconds>48&&<Sequence from={48*warmupShortFps} durationInFrames={32}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.023}/></Sequence>}
</>;

export const WarmupShort:React.FC=()=>{
  let at=0;
  return <AbsoluteFill style={{background:'#0c1214'}}>
    {warmupShortCuts.map((cut,i)=>{const from=at;at+=cut.seconds*warmupShortFps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*warmupShortFps} name={`${i+1}: ${cut.name}`}><VerticalShot {...cut}/></Sequence>})}
    <Soundtrack seconds={58}/>
    {warmupShortCaptions.map((c,i)=><Sequence key={i} from={c.from*warmupShortFps} durationInFrames={c.seconds*warmupShortFps} name={c.text}>
      <Message text={c.text} frames={c.seconds*warmupShortFps}/>
    </Sequence>)}
  </AbsoluteFill>;
};

const previewCuts=[warmupShortCuts[0],warmupShortCuts[1],warmupShortCuts[5],warmupShortCuts[6],warmupShortCuts[9],warmupShortCuts[11]];
export const WarmupShortPreview:React.FC=()=>{
  let at=0;
  const cuts=previewCuts.map((c,i)=>({...c,seconds:i===5?3:4}));
  return <AbsoluteFill style={{background:'#0c1214'}}>
    {cuts.map((cut,i)=>{const from=at;at+=cut.seconds*warmupShortFps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*warmupShortFps}><VerticalShot {...cut}/></Sequence>})}
    <Soundtrack seconds={23}/>
    {[{from:0,text:'WORKOUT SURU HUNU AGADI...'},{from:4,text:'PREPARATION MATTERS.'},
      {from:9,text:'MOVEMENT FIRST.'},{from:16,text:'BODY READY GARA.'},{from:20,text:'1% BETTER EVERY DAY.'}]
      .map((c,i)=><Sequence key={i} from={c.from*warmupShortFps} durationInFrames={3*warmupShortFps}>
        <Message text={c.text} frames={3*warmupShortFps}/>
      </Sequence>)}
  </AbsoluteFill>;
};

export const WarmupShortCompositions=()=> <>
  <Composition id="WarmupShort58s" component={WarmupShort} durationInFrames={warmupShortFrames} fps={warmupShortFps} width={1080} height={1920}/>
  <Composition id="WarmupShortPreview" component={WarmupShortPreview} durationInFrames={23*warmupShortFps} fps={warmupShortFps} width={360} height={640}/>
</>;
