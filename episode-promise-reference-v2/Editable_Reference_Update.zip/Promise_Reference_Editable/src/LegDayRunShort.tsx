import React from 'react';
import {AbsoluteFill,Audio,Composition,Img,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import plan from './leg-run-short-edit.json';
type Cut=(typeof plan.cuts)[number];
type Cue=(typeof plan.captions)[number];
const fps=30, source=staticFile(plan.source), ending=staticFile(plan.closingImage);

const Shot:React.FC<{cut:Cut}>=({cut})=>{
  const {width,height}=useVideoConfig();
  const k=width/1080,wide=cut.layout==='wide',s=wide?1.25*k:height/720;
  const w=1280*s,h=720*s,left=width/2-cut.centerX*s,top=wide?(height-h)/2:0;
  const look=plan.looks[cut.section as keyof typeof plan.looks];
  const bg=cut.background?staticFile(`media/leg-run-short-bg/${cut.background}.jpg`):ending;
  return <AbsoluteFill style={{background:'#101820',overflow:'hidden'}}>
    {wide&&<><Img src={bg} style={{width:'100%',height:'100%',objectFit:'cover',filter:'blur(48px) brightness(.36) saturate(.75)',scale:1.13}}/>
      <AbsoluteFill style={{background:'linear-gradient(to bottom,rgba(5,10,16,.25),transparent 38%,transparent 68%,rgba(5,10,16,.3))'}}/></>}
    <div style={{position:'absolute',width:w,height:h,left,top,overflow:'hidden',boxShadow:wide?'0 25px 85px #000a':'none',outline:wide?`${2*k}px solid #dce8e544`:'none'}}>
      {cut.layout==='still'?<Img src={ending} style={{width:w,height:h,filter:look}}/>:
        <OffthreadVideo src={source} muted trimBefore={Math.round(cut.sourceStart*fps)} durationInFrames={cut.seconds*fps} style={{width:w,height:h,filter:look}}/>}
      {cut.mask==='distance'&&<div style={{position:'absolute',left:420*s,top:315*s,width:325*s,height:96*s,
        background:'rgba(20,24,27,.99)',borderRadius:3*s,display:'flex',alignItems:'center',paddingLeft:116*s,
        boxSizing:'border-box',font:`800 ${30*s}px Arial, Helvetica, sans-serif`,color:'#f7f7f2',letterSpacing:1*s}}>RUNNING</div>}
      {cut.mask==='press45'&&<div style={{position:'absolute',left:495*s,top:505*s,width:335*s,height:125*s,
        background:'rgba(15,21,29,.98)',borderLeft:`${5*s}px solid #b7c9ca`,boxSizing:'border-box',
        display:'flex',alignItems:'center',paddingLeft:20*s,font:`800 ${34*s}px Arial, Helvetica, sans-serif`,
        color:'#f7f7f2',letterSpacing:1*s}}>LEG PRESS</div>}
    </div>
  </AbsoluteFill>;
};

const Caption:React.FC<{cue:Cue}>=({cue})=>{
  const frame=useCurrentFrame(),{width}=useVideoConfig(),k=width/1080,frames=cue.seconds*fps;
  const opacity=interpolate(frame,[0,8,Math.max(9,frames-10),frames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const rise=interpolate(frame,[0,12],[16,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const bottom=cue.position==='bottom';
  return <AbsoluteFill style={{justifyContent:bottom?'flex-end':'flex-start',alignItems:'flex-start',
    padding:bottom?`0 ${72*k}px ${265*k}px`:`${185*k}px ${72*k}px 0`,pointerEvents:'none',
    background:bottom?'linear-gradient(to top,rgba(2,7,12,.55),transparent 30%)':'linear-gradient(to bottom,rgba(2,7,12,.40),transparent 28%)'}}>
    <div style={{width:94*k,height:6*k,background:'#b7c9ca',marginBottom:18*k,opacity}}/>
    <div style={{maxWidth:940*k,whiteSpace:'pre-line',font:`800 ${cue.text.length>20?61*k:70*k}px Arial, Helvetica, sans-serif`,
      lineHeight:1.06,letterSpacing:.2*k,color:'#f7f7f2',textShadow:'0 3px 16px #000',opacity,
      transform:`translateY(${rise*k}px)`}}>{cue.text}</div>
  </AbsoluteFill>;
};

const Soundtrack:React.FC<{seconds:number;transitionAt:number}>=({seconds,transitionAt})=>{
  const start=seconds-11,endFrames=11*fps;
  return <>
    <Audio src={staticFile(plan.music.main)} volume={f=>plan.music.mainVolume*interpolate(f,[0,10,start*fps,(start+3)*fps],[.8,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
    <Sequence from={start*fps} durationInFrames={endFrames}><Audio src={staticFile(plan.music.ending)} trimBefore={30*fps}
      volume={f=>plan.music.endingVolume*interpolate(f,[0,40,endFrames-90,endFrames-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/></Sequence>
    <Sequence durationInFrames={28}><Audio src={staticFile(plan.music.sfx)} volume={.045}/></Sequence>
    <Sequence from={transitionAt*fps} durationInFrames={28}><Audio src={staticFile(plan.music.sfx)} volume={.03}/></Sequence>
  </>;
};

const Story:React.FC<{cuts:Cut[];captions:Cue[];seconds:number;transitionAt:number}>=({cuts,captions,seconds,transitionAt})=>{
  let cursor=0;
  return <AbsoluteFill style={{background:'#101820'}}>
    {cuts.map((cut,i)=>{const from=cursor;cursor+=cut.seconds*fps;return <Sequence key={i} from={from} durationInFrames={cut.seconds*fps} name={`${i+1}. ${cut.name}`}><Shot cut={cut}/></Sequence>})}
    <Soundtrack seconds={seconds} transitionAt={transitionAt}/>
    {captions.map((cue,i)=><Sequence key={i} from={cue.at*fps} durationInFrames={cue.seconds*fps} name={`Caption: ${cue.text}`}><Caption cue={cue}/></Sequence>)}
  </AbsoluteFill>;
};

const selection=[0,2,4,5,10,12];
const previewCuts:Cut[]=selection.map((i,j)=>({...plan.cuts[i],seconds:j===4?4:3}));
const previewCaptions:Cue[]=[
  {at:0,seconds:3,text:'LEG DAY.\nNO SHORTCUTS.',position:'top'},
  {at:3,seconds:3,text:'LEG PRESS',position:'top'},
  {at:6,seconds:3,text:'CALF RAISES',position:'bottom'},
  {at:9,seconds:3,text:'SQUATS',position:'top'},
  {at:12,seconds:3,text:'TESPACHI, TREADMILL.',position:'bottom'},
  {at:16,seconds:3,text:'1% BETTER EVERY DAY.',position:'bottom'}
];
export const LegDayRunShort:React.FC=()=> <Story cuts={plan.cuts} captions={plan.captions} seconds={58} transitionAt={43}/>;
export const LegDayRunShortPreview:React.FC=()=> <Story cuts={previewCuts} captions={previewCaptions} seconds={19} transitionAt={12}/>;
export const LegDayRunShortCompositions=()=> <>
  <Composition id="LegDayRunShort58s" component={LegDayRunShort} durationInFrames={1740} fps={30} width={1080} height={1920}/>
  <Composition id="LegDayRunShortPreview" component={LegDayRunShortPreview} durationInFrames={570} fps={30} width={360} height={640}/>
</>;
