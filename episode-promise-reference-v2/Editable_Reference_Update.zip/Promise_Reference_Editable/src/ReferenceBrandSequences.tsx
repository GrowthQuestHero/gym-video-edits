import React from 'react';
import {AbsoluteFill, Audio, Composition, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export type ReferenceBrandProps = {
  channelName: string;
  tagline: string;
  durationFrames: number;
  accentColor: string;
  backgroundColor: string;
  footageOne?: string;
  footageTwo?: string;
  footageThree?: string;
  beatOneText?: string;
  beatTwoText?: string;
  music?: string;
  soundEffect?: string;
  showEndScreenGuides?: boolean;
};

const bounded = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const font = 'Avenir Next Condensed, Arial Narrow, Arial, sans-serif';
const source = (path: string) => path.startsWith('http') ? path : staticFile(path);

const referenceDefaults: ReferenceBrandProps = {
  channelName: '1% BETTER WITH BIBEK',
  tagline: '1% BETTER EVERY DAY.',
  durationFrames: 186,
  accentColor: '#d71936',
  backgroundColor: '#050608',
  footageOne: 'media/upper-body-science-v2/shot_01.mp4',
  footageTwo: 'media/upper-body-science-v2/shot_08.mp4',
  footageThree: 'media/upper-body-science-v2/shot_16.mp4',
  music: 'media/driving-ambition.mp3',
  soundEffect: 'media/run-small-sweep.wav',
};

type ShotProps = {file?: string; label: string; accent: string; first?: boolean; glitch?: boolean; flash?: boolean};
const MontageShot: React.FC<ShotProps> = ({file, label, accent, first = false, glitch = false, flash = false}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const k = width / 1920;
  const activeGlitch = glitch && frame >= 22 && frame <= 26;
  const offset = activeGlitch ? (frame % 2 === 0 ? 13 : -10) : 0;
  const words = label.trim().toUpperCase().split(/\s+/);
  const finalWord = words.pop() ?? '';
  return <AbsoluteFill style={{background: '#080c12', overflow: 'hidden'}}>
    {file ? <OffthreadVideo src={source(file)} muted style={{width: '100%', height: '100%', objectFit: 'cover', scale: 1.015, translate: `${offset}px 0`, filter: 'contrast(1.11) saturate(.86) brightness(.88)'}} /> : null}
    <AbsoluteFill style={{background: 'rgba(8,22,47,.19)'}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, transparent 22%, rgba(0,0,0,.43) 80%)'}} />
    {activeGlitch ? <AbsoluteFill style={{background: 'repeating-linear-gradient(0deg, transparent 0px, transparent 17px, rgba(255,255,255,.17) 18px, transparent 20px)', mixBlendMode: 'screen'}} /> : null}
    {flash && frame < 3 ? <AbsoluteFill style={{background: '#f1f4f7', opacity: interpolate(frame, [0, 2], [.52, 0], bounded)}} /> : null}
    <div style={{position: 'absolute', left: width * .045, right: width * .045, top: first ? height * .515 : height * .44,
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 18 * k, whiteSpace: 'nowrap',
      color: first ? '#f7f8f5' : accent, fontFamily: font, fontWeight: 900, fontStretch: 'condensed',
      fontSize: (first ? 150 : 136) * k, lineHeight: 1, letterSpacing: -2 * k, textShadow: '0 4px 12px #000',
      opacity: interpolate(frame, [0, 3, 6], [0, .35, 1], bounded),
      scale: interpolate(frame, [0, 7], [1.045, 1], bounded)}}>
      {first ? <><span>{words.join(' ')}</span><span style={{color: accent}}>{finalWord}</span></> : label}
    </div>
  </AbsoluteFill>;
};

const TypeCard: React.FC<{props: ReferenceBrandProps; endScreen?: boolean}> = ({props, endScreen = false}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const k = width / 1920;
  const opacity = interpolate(frame, [0, 9], [0, 1], bounded);
  const nameWords = props.channelName.trim().toUpperCase().split(/\s+/);
  const firstWord = nameWords[0] ?? '';
  const topRest = nameWords.slice(1, 2).join(' ');
  const secondLine = nameWords.slice(2).join(' ');
  return <AbsoluteFill style={{backgroundColor: props.backgroundColor, color: '#f8f8f5', fontFamily: font}}>
    <div style={{position: 'absolute', top: endScreen ? height * .37 : height * .43,
      left: endScreen ? width * .075 : width * .1, width: endScreen ? width * .37 : width * .8,
      textAlign: endScreen ? 'left' : 'center', opacity}}>
      <div style={{fontSize: (endScreen ? 108 : 105) * k, fontWeight: 900, lineHeight: 1, letterSpacing: -.5 * k, whiteSpace: 'nowrap'}}>
        <span style={{color: props.accentColor}}>{firstWord}</span> {topRest}
      </div>
      <div style={{fontSize: 52 * k, fontWeight: 800, lineHeight: 1.2, letterSpacing: .8 * k}}>{secondLine}</div>
      {endScreen && props.tagline ? <div style={{marginTop: 20 * k, fontSize: 36 * k, fontWeight: 700, letterSpacing: .6 * k, opacity: .82}}>{props.tagline}</div> : null}
    </div>
    {endScreen && props.showEndScreenGuides ? <>
      <div style={{position: 'absolute', left: width * .52, top: height * .22, width: width * .33, height: height * .33, border: `2px dashed ${props.accentColor}`, color: props.accentColor, display: 'grid', placeItems: 'center', fontSize: 22 * k}}>NEXT VIDEO GUIDE</div>
      <div style={{position: 'absolute', left: width * .88, top: height * .27, width: 120 * k, height: 120 * k, border: `2px dashed ${props.accentColor}`, borderRadius: '50%', color: props.accentColor, display: 'grid', placeItems: 'center', fontSize: 17 * k}}>SUBSCRIBE GUIDE</div>
    </> : null}
  </AbsoluteFill>;
};

export const ReferenceBrandIntro: React.FC<ReferenceBrandProps> = (props) => {
  const {fps} = useVideoConfig();
  const total = props.durationFrames;
  const scale = Math.min(total / 165, 1);
  const a = Math.round(15 * scale);
  const b = Math.round(40 * scale);
  const c = Math.round(91 * scale);
  const card = Math.round(150 * scale);
  return <AbsoluteFill style={{backgroundColor: props.backgroundColor}}>
    <Sequence from={a} durationInFrames={b - a} premountFor={fps}><MontageShot file={props.footageOne} label={props.channelName} accent={props.accentColor} first /></Sequence>
    <Sequence from={b} durationInFrames={c - b} premountFor={fps}><MontageShot file={props.footageTwo} label={props.beatOneText ?? 'CONSISTENCY'} accent={props.accentColor} glitch /></Sequence>
    <Sequence from={c} durationInFrames={card - c} premountFor={fps}><MontageShot file={props.footageThree} label={props.beatTwoText ?? 'TRAINING'} accent={props.accentColor} flash /></Sequence>
    <Sequence from={card} durationInFrames={total - card} premountFor={fps}><TypeCard props={props} /></Sequence>
    {props.music ? <Audio src={source(props.music)} trimBefore={16 * fps} volume={(f) => .16 * interpolate(f, [0, a + 4, total - 18, total - 1], [0, 1, 1, 0], bounded)} /> : null}
    {props.soundEffect ? <>
      <Sequence from={b} durationInFrames={Math.min(26, total - b)} premountFor={fps}><Audio src={source(props.soundEffect)} volume={(f) => .025 * interpolate(f, [0, 3, Math.max(4, Math.min(26, total - b) - 8), Math.min(26, total - b) - 1], [0, 1, 1, 0], bounded)} /></Sequence>
      <Sequence from={c} durationInFrames={Math.min(26, total - c)} premountFor={fps}><Audio src={source(props.soundEffect)} volume={(f) => .035 * interpolate(f, [0, 3, Math.max(4, Math.min(26, total - c) - 8), Math.min(26, total - c) - 1], [0, 1, 1, 0], bounded)} /></Sequence>
    </> : null}
  </AbsoluteFill>;
};

export const ReferenceBrandOutro: React.FC<ReferenceBrandProps> = (props) => {
  const {fps} = useVideoConfig();
  return <AbsoluteFill style={{backgroundColor: props.backgroundColor}}>
    <TypeCard props={props} endScreen />
    {props.music ? <Audio src={source(props.music)} trimBefore={16 * fps} volume={(f) => .11 * interpolate(f, [0, 12, props.durationFrames - 24, props.durationFrames - 1], [0, 1, 1, 0], bounded)} /> : null}
  </AbsoluteFill>;
};

const DemoFootage: React.FC<{file: string}> = ({file}) => <AbsoluteFill style={{background: '#080c12'}}>
  <OffthreadVideo src={staticFile(file)} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} />
</AbsoluteFill>;

export const ReferenceBrandIntegration: React.FC = () => <AbsoluteFill style={{background: '#050608'}}>
  <Sequence durationInFrames={30}><DemoFootage file="media/upper-body-science-v2/shot_01.mp4" /></Sequence>
  <Sequence from={30} durationInFrames={186}><ReferenceBrandIntro {...referenceDefaults} /></Sequence>
  <Sequence from={216} durationInFrames={30}><DemoFootage file="media/upper-body-science-v2/shot_08.mp4" /></Sequence>
</AbsoluteFill>;

export const ReferenceBrandCompositions: React.FC = () => <>
  <Composition id="ReferenceBrandIntro" component={ReferenceBrandIntro} durationInFrames={186} calculateMetadata={({props}) => ({durationInFrames: props.durationFrames})} fps={30} width={1920} height={1080} defaultProps={{channelName: '1% BETTER WITH BIBEK', tagline: '1% BETTER EVERY DAY.', durationFrames: 186, accentColor: '#d71936', backgroundColor: '#050608', footageOne: 'media/upper-body-science-v2/shot_01.mp4', footageTwo: 'media/upper-body-science-v2/shot_08.mp4', footageThree: 'media/upper-body-science-v2/shot_16.mp4', music: 'media/driving-ambition.mp3', soundEffect: 'media/run-small-sweep.wav'}} />
  <Composition id="ReferenceBrandOutro" component={ReferenceBrandOutro} durationInFrames={210} calculateMetadata={({props}) => ({durationInFrames: props.durationFrames})} fps={30} width={1920} height={1080} defaultProps={{channelName: '1% BETTER WITH BIBEK', tagline: '', durationFrames: 210, accentColor: '#d71936', backgroundColor: '#050608', music: 'media/driving-ambition.mp3', showEndScreenGuides: false}} />
  <Composition id="ReferenceBrandIntegration" component={ReferenceBrandIntegration} durationInFrames={246} fps={30} width={1920} height={1080} />
</>;
