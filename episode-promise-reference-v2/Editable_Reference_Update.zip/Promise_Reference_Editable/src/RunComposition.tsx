import React from 'react';
import {AbsoluteFill,Audio,Composition,OffthreadVideo,Sequence,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {runCuts,runDuration,runFps,type RunCut,type RunSection} from './run-config';

const source=staticFile('media/running-source.mp4');
const grade:Record<RunSection,string>={
  hook:'brightness(1.10) contrast(1.03) saturate(.93)',
  establish:'brightness(1.05) contrast(1.03) saturate(.94)',
  warmup:'brightness(1.07) contrast(1.03) saturate(.94)',
  prepare:'brightness(1.04) contrast(1.03) saturate(.95)',
  run:'brightness(1.08) contrast(1.03) saturate(.94)',
  pause:'brightness(1.07) contrast(1.03) saturate(.94)',
  side:'brightness(1.10) contrast(1.02) saturate(.94)',
  stop:'brightness(1.10) contrast(1.02) saturate(.94)',
  recover:'brightness(1.10) contrast(1.02) saturate(.94)',
  ending:'brightness(1.08) contrast(1.02) saturate(.94)',
};

const RunScene:React.FC<RunCut>=({sourceStart,duration,section})=>{
  const f=useCurrentFrame();
  const zoom=section==='hook'?interpolate(f,[0,duration*runFps],[1.005,1.03],{extrapolateRight:'clamp'}):1;
  return <AbsoluteFill style={{background:'#080c0e',overflow:'hidden'}}>
    <OffthreadVideo src={source} muted trimBefore={sourceStart*runFps} durationInFrames={duration*runFps}
      style={{width:1280,height:720,scale:zoom,filter:grade[section]}}/>
  </AbsoluteFill>;
};

const Caption:React.FC<{text:string;duration:number}>=({text,duration})=>{
  const f=useCurrentFrame();
  const opacity=interpolate(f,[0,10,Math.max(11,duration-12),duration],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const rise=interpolate(f,[0,14],[12,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <div style={{position:'absolute',left:60,bottom:72,maxWidth:650,padding:'16px 21px',
    background:'rgba(6,12,15,.67)',borderLeft:'4px solid #a8d0c8',
    font:'800 48px Arial, Helvetica, sans-serif',letterSpacing:-.7,lineHeight:1.07,color:'#f6f7f3',
    textShadow:'0 2px 11px #000',opacity,translate:`0 ${rise}px`}}>{text}</div>;
};

const Music:React.FC<{from:number;duration:number;file:string;level:number;trim?:number}>=({from,duration,file,level,trim=0})=><Sequence from={from*runFps} durationInFrames={duration*runFps}>
  <Audio src={staticFile(`media/${file}`)} trimBefore={trim*runFps}
    volume={f=>interpolate(f,[0,36,Math.max(37,duration*runFps-75),duration*runFps],[0,level,level,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
</Sequence>;

const Soundtrack:React.FC=()=> <>
  <Music from={0} duration={10} file="driving-ambition.mp3" level={.14} trim={16}/>
  <Music from={8} duration={37} file="run-discover.mp3" level={.14} trim={10}/>
  <Music from={42} duration={150} file="run-deep-urban.mp3" level={.17}/>
  <Music from={190} duration={17} file="run-drawing-sky.mp3" level={.15} trim={24}/>
  <Music from={204} duration={20} file="run-new-life.mp3" level={.13} trim={30}/>
  <Sequence from={42*runFps} durationInFrames={35}><Audio src={staticFile('media/run-small-sweep.wav')} volume={.04}/></Sequence>
</>;

const captions=[
  {from:0,duration:4,text:'AAJA KO CHALLENGE...'},
  {from:8,duration:4,text:'1% BETTER WITH BIBEK  •  RUN DAY'},
  {from:16,duration:3,text:'PAHILA, TAYARI.'},
  {from:42,duration:3,text:'RUN SURU.'},
  {from:114,duration:3,text:'FERI RUN SURU.'},
  {from:156,duration:3,text:'EK STEP AT A TIME.'},
  {from:190,duration:3,text:'AAJA KO RUN YAHI SAKIYO.'},
  {from:215,duration:4,text:'1% BETTER EVERY DAY.'},
];

export const RunningStory:React.FC=()=>{
  let at=0;
  return <AbsoluteFill style={{background:'#080c0e'}}>
    {runCuts.map((cut,i)=>{const from=at;at+=cut.duration*runFps;return <Sequence key={i} from={from} durationInFrames={cut.duration*runFps} name={`${i+1}: ${cut.name}`}><RunScene {...cut}/></Sequence>})}
    <Soundtrack/>
    {captions.map((caption,i)=><Sequence key={i} from={caption.from*runFps} durationInFrames={caption.duration*runFps} name={`Caption: ${caption.text}`}><Caption text={caption.text} duration={caption.duration*runFps}/></Sequence>)}
  </AbsoluteFill>;
};

const previewCuts:RunCut[]=[
  {sourceStart:200,duration:6,section:'hook',name:'Hook'},
  {sourceStart:28,duration:6,section:'warmup',name:'Warm-up'},
  {sourceStart:158,duration:7,section:'side',name:'Running'},
  {sourceStart:237,duration:6,section:'side',name:'Side angle'},
  {sourceStart:335,duration:6,section:'ending',name:'Closing'},
];
export const RunningPreview:React.FC=()=>{
  let at=0;
  return <AbsoluteFill>{previewCuts.map((cut,i)=>{const from=at;at+=cut.duration*runFps;return <Sequence key={i} from={from} durationInFrames={cut.duration*runFps}><RunScene {...cut}/></Sequence>})}
    <Music from={0} duration={7} file="driving-ambition.mp3" level={.14} trim={16}/>
    <Music from={6} duration={7} file="run-discover.mp3" level={.14} trim={10}/>
    <Music from={12} duration={13} file="run-deep-urban.mp3" level={.17}/>
    <Music from={24} duration={7} file="run-new-life.mp3" level={.13} trim={30}/>
    <Sequence durationInFrames={4*runFps}><Caption text="AAJA KO CHALLENGE..." duration={4*runFps}/></Sequence>
    <Sequence from={6*runFps} durationInFrames={3*runFps}><Caption text="PAHILA, TAYARI." duration={3*runFps}/></Sequence>
    <Sequence from={12*runFps} durationInFrames={3*runFps}><Caption text="RUN SURU." duration={3*runFps}/></Sequence>
    <Sequence from={25*runFps} durationInFrames={5*runFps}><Caption text="1% BETTER EVERY DAY." duration={5*runFps}/></Sequence>
  </AbsoluteFill>;
};

export const RunCompositions=()=> <>
  <Composition id="RunningStoryFinal" component={RunningStory} durationInFrames={runDuration*runFps} fps={runFps} width={1280} height={720}/>
  <Composition id="RunningStoryPreview" component={RunningPreview} durationInFrames={31*runFps} fps={runFps} width={1280} height={720}/>
</>;
