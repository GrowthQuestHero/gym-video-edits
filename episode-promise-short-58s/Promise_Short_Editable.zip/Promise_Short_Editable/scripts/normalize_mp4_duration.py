#!/usr/bin/env python3
"""Trim only the known 5 ms AAC presentation tail from a Promise Short MP4.

Usage: python normalize_mp4_duration.py export.mp4 [--report report.json]
Requires ffprobe. Encoded video/audio samples are never changed or re-encoded.
Accepts the 1080x1920 final or its 540x960 verification preview only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
import subprocess
import sys
import tempfile
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

TARGET = 58000
PRISTINE = 58005


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def boxes(data: bytes | bytearray, start: int = 0, end: int | None = None) -> list[dict]:
    end = len(data) if end is None else end
    found = []
    position = start
    while position < end:
        require(position + 8 <= end, f'Truncated MP4 box at {position}')
        size, kind = struct.unpack_from('>I4s', data, position)
        header = 8
        if size == 1:
            require(position + 16 <= end, 'Truncated extended MP4 box header')
            size = struct.unpack_from('>Q', data, position + 8)[0]
            header = 16
        elif size == 0:
            size = end - position
        require(size >= header and position + size <= end, f'Invalid {kind!r} box length')
        found.append(dict(kind=kind, start=position, payload=position + header, end=position + size))
        position += size
    require(position == end, 'MP4 box boundaries do not align')
    return found


def only(children: list[dict], kind: bytes) -> dict:
    matches = [box for box in children if box['kind'] == kind]
    require(len(matches) == 1, f'Expected exactly one {kind.decode()} box, got {len(matches)}')
    return matches[0]


def children(data: bytes | bytearray, parent: dict) -> list[dict]:
    return boxes(data, parent['payload'], parent['end'])


def payload_hashes(data: bytes | bytearray) -> dict:
    combined = hashlib.sha256()
    rows = []
    view = memoryview(data)
    for box in boxes(data):
        if box['kind'] == b'mdat':
            payload = view[box['payload']:box['end']]
            digest = hashlib.sha256(payload).hexdigest()
            combined.update(payload)
            rows.append(dict(bytes=len(payload), sha256=digest))
    require(bool(rows), 'No encoded media payload (mdat) found')
    return dict(mdat_boxes=rows, combined_sha256=combined.hexdigest())


def normalize_bytes(original: bytes) -> tuple[bytes, dict]:
    data = bytearray(original)
    top = boxes(data)
    require(not any(box['kind'] == b'moof' for box in top), 'Fragmented MP4 is unsupported')
    moov = only(top, b'moov')
    movie_children = children(data, moov)
    mvhd = only(movie_children, b'mvhd')
    require(data[mvhd['payload']] == 0, 'Expected version-0 mvhd')
    movie_scale = struct.unpack_from('>I', data, mvhd['payload'] + 12)[0]
    require(movie_scale == 1000, f'Expected movie timescale 1000, got {movie_scale}')
    movie_duration_position = mvhd['payload'] + 16
    movie_duration = struct.unpack_from('>I', data, movie_duration_position)[0]
    require(movie_duration in (PRISTINE, TARGET), f'Unexpected movie duration {movie_duration}')
    tracks = [box for box in movie_children if box['kind'] == b'trak']
    require(len(tracks) == 2, f'Expected exactly two MP4 tracks, got {len(tracks)}')
    by_handler = {}
    for track in tracks:
        track_children = children(data, track)
        tkhd = only(track_children, b'tkhd')
        mdia = only(track_children, b'mdia')
        media_children = children(data, mdia)
        hdlr = only(media_children, b'hdlr')
        handler = bytes(data[hdlr['payload'] + 8:hdlr['payload'] + 12])
        require(handler in (b'vide', b'soun') and handler not in by_handler, 'Expected one video and one sound track')
        require(data[tkhd['payload']] == 0, 'Expected version-0 tkhd')
        edts = only(track_children, b'edts')
        elst = only(children(data, edts), b'elst')
        require(data[elst['payload']] == 0, 'Expected version-0 elst')
        require(struct.unpack_from('>I', data, elst['payload'] + 4)[0] == 1, 'Expected one edit-list entry')
        require(elst['end'] - elst['payload'] == 20, 'Unexpected edit-list payload length')
        media_time = struct.unpack_from('>i', data, elst['payload'] + 12)[0]
        rate_integer, rate_fraction = struct.unpack_from('>hh', data, elst['payload'] + 16)
        require(media_time >= 0 and (rate_integer, rate_fraction) == (1, 0), 'Unexpected edit offset or playback rate')
        tkhd_position = tkhd['payload'] + 20
        elst_position = elst['payload'] + 8
        by_handler[handler] = dict(tkhd_position=tkhd_position, elst_position=elst_position,
                                  tkhd_duration=struct.unpack_from('>I', data, tkhd_position)[0],
                                  elst_duration=struct.unpack_from('>I', data, elst_position)[0],
                                  media_time=media_time)
    require(set(by_handler) == {b'vide', b'soun'}, 'Expected exactly one video and one sound track')
    video, audio = by_handler[b'vide'], by_handler[b'soun']
    require(video['tkhd_duration'] == TARGET and video['elst_duration'] == TARGET,
            'Video track/edit-list must already be exactly 58.000 seconds')
    require(audio['tkhd_duration'] == movie_duration and audio['elst_duration'] == movie_duration,
            'Movie and audio declared durations disagree; refusing a partial or unexpected patch')
    edits = []
    if movie_duration == PRISTINE:
        for name, position in [('mvhd.duration', movie_duration_position),
                               ('audio.tkhd.duration', audio['tkhd_position']),
                               ('audio.elst.segment_duration', audio['elst_position'])]:
            require(struct.unpack_from('>I', data, position)[0] == PRISTINE, f'{name} is not exactly 58005')
            struct.pack_into('>I', data, position, TARGET)
            edits.append(dict(field=name, byte_offset=position, previous=PRISTINE, normalized=TARGET))
    changed_positions = {position + byte for edit in edits for position in [edit['byte_offset']] for byte in range(4)}
    require(all(before == after or index in changed_positions for index, (before, after) in enumerate(zip(original, data))),
            'A byte outside the three duration fields changed')
    require(len(data) == len(original), 'MP4 byte length changed')
    before_payload = payload_hashes(original)
    after_payload = payload_hashes(data)
    require(before_payload == after_payload, 'Encoded media payload changed')
    return bytes(data), dict(action='normalized' if edits else 'already_exact_noop',
                             movie_timescale=movie_scale, previous_duration_seconds=movie_duration / movie_scale,
                             normalized_duration_seconds=58.0, modified_fields=edits,
                             video_duration_fields_unchanged=True, audio_media_time_unchanged=audio['media_time'],
                             media_payload_before=before_payload, media_payload_after=after_payload,
                             encoded_payload_identical=True, file_size_unchanged=True)


def probe(path: Path, target_only: bool = False) -> dict:
    process = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
                             capture_output=True, text=True, check=True)
    require(not process.stderr.strip(), 'ffprobe reported errors')
    result = json.loads(process.stdout)
    streams = result['streams']
    require(len(streams) == 2, 'Expected exactly two streams')
    videos = [stream for stream in streams if stream['codec_type'] == 'video']
    audios = [stream for stream in streams if stream['codec_type'] == 'audio']
    require(len(videos) == 1 and len(audios) == 1, 'Expected exactly one video and one audio stream')
    video, audio = videos[0], audios[0]
    require(video['codec_name'] == 'h264' and audio['codec_name'] == 'aac', 'Expected H.264/AAC')
    require((video['width'], video['height']) in ((1080, 1920), (540, 960)), 'Expected Promise vertical final or preview dimensions')
    require(int(video['nb_frames']) == 1740, 'Expected exactly 1740 video frames')
    require(Fraction(video['r_frame_rate']) == 30 and Fraction(video['avg_frame_rate']) == 30, 'Expected 30 fps')
    require(Decimal(video['duration']) == Decimal('58'), 'Video must already be exactly 58 seconds')
    require(Decimal(video['start_time']) == 0 and Decimal(audio['start_time']) == 0, 'Unexpected nonzero stream start')
    require(int(audio['sample_rate']) == 48000 and audio['channels'] == 2, 'Expected 48 kHz stereo audio')
    allowed = {Decimal('58')} if target_only else {Decimal('58'), Decimal('58.005')}
    audio_duration = Decimal(audio['duration'])
    format_duration = Decimal(result['format']['duration'])
    require(audio_duration in allowed and format_duration == audio_duration,
            f'Unexpected audio/container durations: {audio_duration}/{format_duration}')
    return dict(video_codec=video['codec_name'], audio_codec=audio['codec_name'], width=video['width'], height=video['height'],
                video_frames=int(video['nb_frames']), video_duration=video['duration'], audio_duration=audio['duration'],
                container_duration=result['format']['duration'], audio_packets=audio.get('nb_frames'),
                video_time_base=video['time_base'], audio_time_base=audio['time_base'])


def normalize_file(path: Path, report_path: Path) -> dict:
    require(not path.is_symlink(), 'Refusing a symlink input')
    path = path.resolve(strict=True)
    require(path.suffix.lower() == '.mp4', 'Input must be an MP4 file')
    report_path = report_path.resolve()
    require(report_path != path, 'Report path must differ from the MP4 input')
    initial_stat = path.stat()
    before_probe = probe(path)
    original = path.read_bytes()
    current_stat = path.stat()
    require((initial_stat.st_size, initial_stat.st_mtime_ns) == (current_stat.st_size, current_stat.st_mtime_ns),
            'Input changed while reading; wait for rendering to finish')
    normalized, report = normalize_bytes(original)
    require(Decimal(before_probe['container_duration']) == Decimal(str(report['previous_duration_seconds'])),
            'ffprobe and MP4 duration fields disagree')
    report.update(file=str(path), size_bytes=len(original), original_sha256=hashlib.sha256(original).hexdigest(),
                  normalized_sha256=hashlib.sha256(normalized).hexdigest(), before_probe=before_probe,
                  reencoded=False, scope='Only mvhd and audio tkhd/elst presentation durations; no media/sample-table edits.')
    temporary_path = None
    try:
        if report['action'] == 'normalized':
            with tempfile.NamedTemporaryFile(prefix='.' + path.stem + '-duration-', suffix='.mp4', dir=path.parent, delete=False) as stream:
                temporary_path = Path(stream.name)
                stream.write(normalized)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary_path, initial_stat.st_mode & 0o777)
            after_probe = probe(temporary_path, target_only=True)
            require(all(before_probe[key] == after_probe[key] for key in
                        ('video_codec', 'audio_codec', 'width', 'height', 'video_frames', 'video_duration',
                         'audio_packets', 'video_time_base', 'audio_time_base')), 'Stream properties changed')
            final_stat = path.stat()
            require((initial_stat.st_size, initial_stat.st_mtime_ns) == (final_stat.st_size, final_stat.st_mtime_ns),
                    'Input changed during verification; refusing to replace it')
            os.replace(temporary_path, path)
            temporary_path = None
        else:
            after_probe = probe(path, target_only=True)
        report['after_probe'] = after_probe
        require(hashlib.sha256(path.read_bytes()).hexdigest() == report['normalized_sha256'], 'Final file hash differs from verified candidate')
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2) + '\n')
        return report
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    report_path = args.report or args.input.with_name(args.input.stem + '.duration-normalization.json')
    try:
        report = normalize_file(args.input, report_path)
    except Exception as error:
        print(f'ERROR: {type(error).__name__}: {error}', file=sys.stderr)
        return 1
    print(f"PASS: {report['action']}; video/AAC/container exactly58.000000s; 1740 video frames; encoded payload unchanged. Report: {report_path}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
