# Reusable animation library

Status: proposed component specifications. These are not implemented templates, reviewed reference animations, or claims about D:\Chat. Build/test only the needed components in an implementation task.

| ID | Graphic | Use when speech... | Change for each episode |
|---|---|---|---|
| ANIM-01 | Exercise label | introduces a movement | name, colors, anchor, entrance, hold, exit |
| ANIM-02 | Sets/reps/weight card | states recorded workout values | sets, reps, weight, units, labels, timing |
| ANIM-03 | Keyword emphasis | makes one important point | exact words, emphasis, color, scale, timing |
| ANIM-04 | Checklist | explains a short sequence | item wording/count, active item, spacing, timing |
| ANIM-05 | Comparison panel | compares recorded sessions | dates, values, units, headings, layout |
| ANIM-06 | Progress chart | discusses real measurements over time | points, labels, axes, honest scale, units, dates |
| ANIM-07 | Arrow/callout | explains a visible detail | target, text, tracking, color, placement |
| ANIM-08 | Timer/progress bar | names an actual duration | start/end, real-time versus compressed display, label |
| ANIM-09 | Chapter card | changes topic | heading, subheading, colors, duration |
| ANIM-10 | Recap/outro | concludes the story | actual takeaway, text, pacing, end-screen layout |

Store stable IDs and a preview per tested aspect ratio. Record entrance, readable hold and exit separately. Keep unknown metrics unknown instead of filling attractive placeholders.

## Actual reference/template review record
ID and exact path:
Related web reference:
Status: not reviewed / reference reviewed / project inspected / render-tested / blocked
What was actually watched or tested:
Timecoded entrance, hold, updates and exit:
Appearance, typography, palette, movement and easing:
Communication purpose and best script triggers:
Text/color/number/point/media/layout/timing controls:
Exact layer/control names and customization procedure:
Fonts, linked assets, application version and plugins:
Limits, unsupported changes and required rebuilds:
License evidence and attribution:
Test values, preview path, horizontal/vertical results:
Uncertainties and review date:

Web discovery is not visual review. A rendered preview does not prove native-project editability. A successful render does not establish a usage license.
