# Reusable free editing workflow

## Budget and execution
Use the existing Remotion gym editor where accessible, FFmpeg for media operations and checks, and local Whisper for transcription. Kdenlive is the optional free visual timeline editor if you want one. Do not install multiple editors without a specific need. After Effects, Premiere, paid templates/plugins, paid AI services and cloud render services are not dependencies.

ChatGPT/Codex supplies editorial reasoning and supported code/tool actions within the subscription's available features and limits. It does not provide a guaranteed unattended folder watcher, permanent storage, unlimited render compute, or local-drive access. OpenAI API billing is separate; this design uses no paid API. Free local tools still use your computer, disk, electricity and download bandwidth.

## Per-episode procedure for the editing assistant
1. Locate actual accessible footage and voiceover. Probe streams, inspect content, build a shot map and preserve originals. Never reuse a previous episode's source timecodes.
2. Transcribe actual speech. Correct exercise names, units, numbers and negations; mark uncertain words. For mixed-language speech, preserve the intended language/script unless translation is requested.
3. Build hook, context, progression and takeaway. Make the rough cut before final subtitle timing. Keep meaningful exercise movement and recovery moments where they support the story.
4. Break speech into beats. For each graphic record final-timeline time, spoken phrase, purpose, animation ID, text, colors, verified values/units, placement, readable hold and exit. Leaving footage clean is valid.
5. Customize working copies or reusable components. Change underlying numbers and graph data, not merely visible text. Recheck units, labels, scale, text wrapping and easing. Native AE projects cannot be assumed to work in the free editor; recreate an appropriate general technique or defer that asset.
6. Generate captions against the edited audio. Use natural phrases, strong contrast and generally one or two lines. Word highlights require word timings; ordinary SRT does not inherently supply them. Keep captions clear of movement, other graphics and platform controls.
7. Make separate horizontal and vertical layouts. Suggested starting sizes: 1920x1080 and 1080x1920. Reframe each shot. Do not crop the entire long edit blindly. Set frame rate from the media and intended edit.
8. Mix clear voiceover; use licensed music/SFX only. Avoid retaining copyright-uncertain gym background music. Correct exposure and white balance before a restrained grade.
9. Review a representative preview with speech, captions and a graphic. Then export once to a new path. Check final duration, decode integrity, dimensions, caption timing, audio and picture.
10. Deliver MP4, corrected SRT, editable project/configuration, cut/graphic plan and QC notes. Publishing needs its own request. Keep limitations explicit.

## Episode files
01 Footage: camera originals. 02 Voiceover: clean audio. 03 Notes: optional brief and verified training log. 04 Project: transcript, shot/graphic plans and editable project. 05 Exports: previews, final outputs, SRT and QC notes.

## Visual defaults
Use a restrained palette drawn from established project branding, one caption style and one complementary label style. Use animation to communicate rather than decorate every sentence. Adapt all words, colors, timing, points and values to the new episode. Never invent personal performance or medical claims. Stock footage must not imply it is footage of the user's own workout.

## Future request
"Use WORKFLOW.md, ANIMATION_LIBRARY.md and REFERENCES.md. Edit [accessible dated folder] into [long / Short / both]. Inspect the footage and actual speech, correct subtitles, select relevant graphics, customize their values and layout, preserve originals and deliver project, MP4, SRT and QC notes. No paid tools, APIs or downloads."
