# Researched references and free asset candidates

Research date: 18 October 2026. No linked videos were watched or downloaded. These are curated research candidates, not completed motion analysis.

## REF-001 — Jeff Nippard - BACK Focused Full Body Workout

- Category: Study
- Source: [Jeff Nippard - BACK Focused Full Body Workout](https://www.youtube.com/watch?v=didU4ZwAkPI)
- Use case: Study voiceover-led workout structure and exercise explanations; inspect visuals before copying any design idea
- Rights: Link only; no reuse permission established
- Review: Search metadata verified; playback not reviewed

## REF-002 — Rogue Fitness - Push Beyond

- Category: Study
- Source: [Rogue Fitness - Push Beyond](https://www.kevincoynedp.com/pushbeyond)
- Use case: Study preparation-to-effort story progression and recovery moments described by the cinematographer
- Rights: Link only; no reuse permission established
- Review: Creator case study read; film not played

## REF-003 — Casey Faris - How I Make Motion Graphics in Fusion

- Category: Tutorial
- Source: [Casey Faris - How I Make Motion Graphics in Fusion](https://www.youtube.com/watch?v=kT2tnCq-Gk0)
- Use case: Candidate for reusable text and shape animation techniques; recreate the principle in our chosen editor
- Rights: Free-to-view reference; Resolve tutorial; not a free AE project
- Review: Search metadata verified; playback not reviewed

## REF-004 — Casey Faris - Animating Motion Graphics in Fusion

- Category: Tutorial
- Source: [Casey Faris - Animating Motion Graphics in Fusion](https://www.youtube.com/watch?v=yj11wSo0Zug)
- Use case: Candidate for timing and custom animation; inspect technique and dependencies before implementation
- Rights: Free-to-view reference; no asset redistribution permission established
- Review: Search metadata verified; playback not reviewed

## REF-005 — Blackmagic official training - Fusion and motion graphics

- Category: Tutorial
- Source: [Blackmagic official training - Fusion and motion graphics](https://www.blackmagicdesign.com/products/davinciresolve/training)
- Use case: Official motion graphics lessons and practice projects; training material is not automatically licensed upload footage
- Rights: Use lessons and practice files under their own terms; optional Resolve path
- Review: Official training page read; lessons not played

## REF-006 — Remotion showcase

- Category: Examples
- Source: [Remotion showcase](https://www.remotion.dev/showcase)
- Use case: Discover styles that may be reproducible in the current code-based editor; evaluate each separately
- Rights: Showcase projects have individual rights; not all source code is supplied
- Review: Discovery link; entries not reviewed

## STOCK-001 — Two people working out

- Category: Stock
- Source: [Two people working out](https://mixkit.co/free-stock-video/two-people-working-out-1318/)
- Use case: Horizontal gym-context insert or typography practice; not personal-session evidence
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Item page read; 26 seconds; 24 fps; not downloaded or played

## STOCK-002 — A healthy couple running on a treadmill

- Category: Stock
- Source: [A healthy couple running on a treadmill](https://mixkit.co/free-stock-video/a-healthy-couple-running-on-a-treadmill-1321/)
- Use case: Vertical cardio example for Short layout and captions
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Search metadata read; 13 seconds; 24 fps; not downloaded or played

## STOCK-003 — Couple exercising with dumbbells in the gym

- Category: Stock
- Source: [Couple exercising with dumbbells in the gym](https://mixkit.co/free-stock-video/couple-exercising-with-dumbbells-in-the-gym-40238/)
- Use case: Practice exercise labels over a medium shot
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Search metadata read; 15 seconds; 24 fps; not downloaded or played

## STOCK-004 — People running on treadmills at the gym

- Category: Stock
- Source: [People running on treadmills at the gym](https://mixkit.co/free-stock-video/people-running-on-treadmills-at-the-gym-100530/)
- Use case: Cardio context and layout testing
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Search metadata read; 16 seconds; 24 fps; not downloaded or played

## STOCK-005 — Man lifting weights in the gym

- Category: Stock
- Source: [Man lifting weights in the gym](https://mixkit.co/free-stock-video/man-lifting-weights-in-the-gym-100544/)
- Use case: Bench-press context; assess actual composition before using callouts
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Search metadata read; not downloaded or played

## STOCK-006 — Woman Exercising on Treadmill at the Gym

- Category: Stock
- Source: [Woman Exercising on Treadmill at the Gym](https://mixkit.co/free-stock-video/woman-exercising-on-treadmill-at-the-gym-100524/)
- Use case: Cardio footage and subtitle contrast testing
- Rights: Item page states Mixkit Stock Video Free License; recheck at download
- Review: Search metadata read; 22 seconds; 24 fps; not downloaded or played

## ASSET-001 — Mixkit free Resolve lower thirds

- Category: Template
- Source: [Mixkit free Resolve lower thirds](https://mixkit.co/free-davinci-resolve-templates/lower-thirds/)
- Use case: Optional source of exercise-card references or native Resolve templates
- Rights: Free downloads advertised; check chosen item license and version; incompatible with Remotion as native projects
- Review: Category page researched; no template downloaded or tested

## ASSET-002 — Pexels video library and license

- Category: Stock library
- Source: [Pexels video library and license](https://www.pexels.com/videos/)
- Use case: Additional contextual footage when personal footage is missing
- Rights: Pexels license applies; inspect asset and use context
- Review: Library and license researched; no assets selected

## AUDIO-001 — YouTube Audio Library guidance

- Category: Audio
- Source: [YouTube Audio Library guidance](https://support.google.com/youtube/answer/3376882?hl=en)
- Use case: Music and sound effects for YouTube; record attribution per track
- Rights: Select tracks in YouTube Studio and retain their actual license and attribution
- Review: Official help researched; no track selected
