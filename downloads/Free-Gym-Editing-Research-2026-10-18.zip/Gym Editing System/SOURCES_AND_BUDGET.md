# Sources, free tools and remaining setup

Research checked 18 October 2026. Recheck changing licenses and software requirements before use.

## Recommended stack
- Existing Remotion 4.0.535 gym project: local package and license were inspected. Its individual-use license permits commercial video creation without a license fee. Preserve the version and existing episodes; do not assume example render commands target new footage. https://www.remotion.dev/docs/license/pricing
- FFmpeg: free software for media inspection, transcoding and delivery. Already available in this cloud workspace; Windows availability unverified. https://ffmpeg.org/about.html
- Local Whisper: downloadable speech recognition code and models; use local inference rather than the paid transcription API. It is not installed in the inspected Python environment. CPU use is possible but speed depends on model and hardware; test a short sample first. https://github.com/openai/whisper
- Optional Kdenlive: free/open-source visual editing and captions. Its documented Whisper support needs setup and model downloads. No installation performed. https://kdenlive.org/ and https://docs.kdenlive.org/en/effects_and_filters/speech_to_text.html
- No extra OpenAI API budget: subscriptions and API usage have separate billing. https://help.openai.com/en/articles/9039756-managing-billing-for-chatgpt-and-the-api-platform

## Footage and audio
Your own gym footage is the default. External references are links for study; no permission to republish creator videos or music is established. Selected Mixkit item pages state Stock Video Free License; keep the applicable license with each actual download. Mixkit also has a Restricted License, and some apparently free gym clips were excluded because they state personal use only. https://mixkit.co/license/ and https://mixkit.co/license/modal/videoFree/

Pexels is another source with its own usage conditions. Keep a source URL and license record per selected asset. https://www.pexels.com/legal-pages/license/

Use YouTube Studio's Audio Library for suitable YouTube music/SFX, recording track-specific attribution where required. No music track has been downloaded or cleared in this kit. https://support.google.com/youtube/answer/3376882?hl=en

Stock Footage and Licenses folders are intentionally empty: no media binaries were downloaded. Do not treat saved links or page descriptions as watched footage. Direct shell downloads from the selected media sites are outside this environment's current network allowlist; no bypass was attempted.

## Practical limits
Windows Documents and D:\Chat are not mounted here. The setup script creates folders only when run on the user's Windows PC. No existing folders are moved or overwritten. The script does not install software or download media.

The current Remotion project is in the cloud workspace; this kit does not bundle it. One separate setup pass must establish which computer executes edits, its hardware/storage, access to source media, free transcription setup and a tested sample render. Full automation is not claimed.

## Reference review integrity
Pages and search metadata were researched; linked videos were not played or visually analyzed. Matching use cases are proposed research directions, not timecoded animation breakdowns. D:\Chat references and templates remain uninspected.
