# Daily gym editing: start here

Research date: 18 October 2026. Budget: no additional software subscriptions or paid API calls.

## Your daily part
1. Film the session and record a clean voiceover, preferably as a separate file.
2. Put them in the dated folder inside Daily Gym Raw Videos. Run New-Day.ps1 to create today's folders.
3. Ask: "Use this gym editing system. Edit today's folder into [long / Short / both], add corrected subtitles, and use relevant customized graphics."

The editor handles the transcript, shot plan, animation selection, replacement values, captions, previews and QC. You do not need to manage twelve editing stages yourself.

## Read once
- WORKFLOW.md explains how the editor works.
- ANIMATION_LIBRARY.md records proposed reusable graphics and their editable values.
- REFERENCES.md and REFERENCES.csv contain researched links and review status.
- SOURCES_AND_BUDGET.md explains the free tools and boundaries.
- Stock Footage stores permitted downloaded examples. Reference Links stores shortcuts. Neither contains downloaded videos yet.

This is a research and organization kit, not a newly implemented automatic editing engine. The current cloud workspace contains a Remotion gym project, but its presence does not put that project on your PC. Local installation, actual file access and a representative render need a separate setup pass.

Keep originals and final files backed up using storage you already own. Preserve any existing D:\Chat folders. These documents do not imply those folders have been inspected.
